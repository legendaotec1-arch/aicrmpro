import { useEffect, useState } from 'react';
import Card, { CardHeader } from '../ui/Card';
import Button from '../ui/Button';
import Input from '../ui/Input';
import { PageLoader } from '../ui/Spinner';

export default function NotifySettingsCard({ api, toast }) {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    notify_telegram_user_id: '',
    notify_max_user_id: '',
    chat_notify_enabled: true,
    review_notify_enabled: true
  });

  useEffect(() => {
    (async () => {
      try {
        const res = await api.get('/master/me/notify-settings');
        setForm({
          notify_telegram_user_id: res.data.notify_telegram_user_id || '',
          notify_max_user_id: res.data.notify_max_user_id || '',
          chat_notify_enabled: res.data.chat_notify_enabled !== false,
          review_notify_enabled: res.data.review_notify_enabled !== false
        });
      } catch {
        toast('Не удалось загрузить настройки уведомлений', 'error');
      } finally {
        setLoading(false);
      }
    })();
  }, [api, toast]);

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await api.put('/master/me/notify-settings', {
        notify_telegram_user_id: form.notify_telegram_user_id.trim() || null,
        notify_max_user_id: form.notify_max_user_id.trim() || null,
        chat_notify_enabled: form.chat_notify_enabled,
        review_notify_enabled: form.review_notify_enabled
      });
      toast('Уведомления сохранены');
    } catch {
      toast('Ошибка сохранения', 'error');
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <PageLoader />;

  return (
    <Card>
      <CardHeader
        title="Push в мессенджер"
        description="Сообщения о новых чатах и отзывах на модерации приходят вам в MAX или Telegram"
      />
      <form onSubmit={handleSave} className="space-y-4 max-w-lg">
        <Input
          label="Ваш Telegram user ID"
          value={form.notify_telegram_user_id}
          onChange={(e) => setForm({ ...form, notify_telegram_user_id: e.target.value })}
          placeholder="Например: 123456789"
        />
        <Input
          label="Ваш MAX user ID"
          value={form.notify_max_user_id}
          onChange={(e) => setForm({ ...form, notify_max_user_id: e.target.value })}
          placeholder="ID из бота MAX"
        />
        <p className="text-xs text-ink-muted -mt-2">
          Узнать ID: напишите боту салона /start — в логах бота или через @userinfobot в Telegram.
        </p>
        <label className="flex items-center gap-2 text-sm cursor-pointer">
          <input
            type="checkbox"
            checked={form.chat_notify_enabled}
            onChange={(e) => setForm({ ...form, chat_notify_enabled: e.target.checked })}
            className="rounded border-slate-300 text-primary-600"
          />
          Уведомлять о новых сообщениях в чате
        </label>
        <label className="flex items-center gap-2 text-sm cursor-pointer">
          <input
            type="checkbox"
            checked={form.review_notify_enabled}
            onChange={(e) => setForm({ ...form, review_notify_enabled: e.target.checked })}
            className="rounded border-slate-300 text-primary-600"
          />
          Уведомлять о новых отзывах (на модерации)
        </label>
        <Button type="submit" loading={saving}>Сохранить</Button>
      </form>
    </Card>
  );
}
