import { useEffect, useState } from 'react';
import Modal from '../ui/Modal';
import Button from '../ui/Button';
import Badge from '../ui/Badge';
import Input from '../ui/Input';
import Textarea from '../ui/Textarea';
import { PageLoader } from '../ui/Spinner';
import MessengerLabel from '../brand/MessengerLabel';
import { STATUS_LABELS, formatDateTime, formatPrice, formatDate } from '../../lib/format';
import { copyToClipboard } from '../../lib/clipboard';

function StatBox({ label, value, hint }) {
  return (
    <div className="rounded-xl bg-slate-50 border border-slate-100 px-3 py-2">
      <p className="text-xs text-ink-muted">{label}</p>
      <p className="text-lg font-bold text-ink">{value}</p>
      {hint && <p className="text-xs text-ink-secondary mt-0.5">{hint}</p>}
    </div>
  );
}

function ContactRow({ label, value, onCopy }) {
  if (!value) return null;
  return (
    <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl bg-slate-50 border border-slate-100 px-3 py-2">
      <div className="min-w-0">
        <p className="text-xs text-ink-muted">{label}</p>
        <p className="text-sm font-medium text-ink break-all">{value}</p>
      </div>
      {onCopy && (
        <Button size="sm" variant="ghost" type="button" onClick={onCopy}>
          Копировать
        </Button>
      )}
    </div>
  );
}

const emptyForm = {
  last_name: '',
  first_name: '',
  patronymic: '',
  phone: '',
  notes: ''
};

export default function ClientDetailModal({
  clientId,
  api,
  onClose,
  toast,
  onMessage,
  onRepeatInvite,
  onSaved
}) {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [data, setData] = useState(null);
  const [form, setForm] = useState(emptyForm);

  useEffect(() => {
    if (!clientId) return;
    let cancelled = false;
    (async () => {
      setLoading(true);
      try {
        const res = await api.get(`/master/me/clients/${clientId}`);
        if (!cancelled) {
          const c = res.data.client;
          setData(res.data);
          setForm({
            last_name: c.last_name || '',
            first_name: c.first_name || '',
            patronymic: c.patronymic || '',
            phone: c.phone || '',
            notes: c.salon_notes || ''
          });
        }
      } catch {
        if (!cancelled) toast('Не удалось загрузить карточку', 'error');
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [clientId, api, toast]);

  const handleSave = async () => {
    setSaving(true);
    try {
      const res = await api.put(`/master/me/clients/${clientId}`, form);
      toast('Карточка сохранена');
      if (res.data?.display_name && data?.client) {
        setData({
          ...data,
          client: {
            ...data.client,
            display_name: res.data.display_name,
            ...form
          }
        });
      }
      onSaved?.();
    } catch {
      toast('Ошибка сохранения', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleCopyId = async (id) => {
    try {
      await copyToClipboard(id);
      toast('ID скопирован');
    } catch {
      toast('Не удалось скопировать', 'error');
    }
  };

  const client = data?.client;
  const stats = data?.stats;
  const appointments = data?.appointments || [];
  const messengerId = client?.messenger === 'telegram'
    ? client?.telegram_user_id
    : client?.max_user_id;
  const canMessage = client?.can_message ?? !!(client?.max_user_id || client?.telegram_user_id);
  const title = client?.display_name || client?.name || 'Клиент';

  return (
    <Modal
      open={!!clientId}
      onClose={onClose}
      title={loading ? 'Клиент' : title}
      description={!loading && client?.phone ? client.phone : undefined}
      size="lg"
    >
      {loading ? (
        <div className="py-12 flex justify-center">
          <PageLoader />
        </div>
      ) : !data ? (
        <p className="text-sm text-ink-muted py-8 text-center">Данные недоступны</p>
      ) : (
        <div className="space-y-6 max-h-[70vh] overflow-y-auto pr-1">
          <section className="space-y-3">
            <h3 className="text-sm font-semibold text-ink">Контакт в мессенджере</h3>
            <div className="flex flex-wrap items-center gap-2">
              <MessengerLabel channel={client.messenger} size="md" />
              {client.created_at && (
                <span className="text-xs text-ink-muted">
                  В базе с {formatDate(client.created_at)}
                </span>
              )}
            </div>
            <p className="text-xs text-ink-muted">
              {client.messenger === 'telegram'
                ? 'Клиент записывался через Telegram — сообщения уходят в Telegram-бот.'
                : 'Клиент записывался через MAX — сообщения уходят в MAX.'}
            </p>
            <ContactRow
              label={client.messenger === 'telegram' ? 'Telegram user ID' : 'MAX user ID'}
              value={messengerId}
              onCopy={messengerId ? () => handleCopyId(messengerId) : undefined}
            />
            {canMessage && (
              <div className="flex flex-wrap gap-2">
                {onMessage && (
                  <Button size="sm" variant="soft" onClick={() => onMessage(client)}>
                    Написать в мессенджер
                  </Button>
                )}
                {onRepeatInvite && (
                  <Button size="sm" variant="secondary" onClick={() => onRepeatInvite(client)}>
                    Пригласить на повтор
                  </Button>
                )}
              </div>
            )}
          </section>

          <section className="space-y-3">
            <h3 className="text-sm font-semibold text-ink">ФИО и телефон</h3>
            <div className="grid gap-3 sm:grid-cols-3">
              <Input
                label="Фамилия"
                value={form.last_name}
                onChange={(e) => setForm({ ...form, last_name: e.target.value })}
                placeholder="Иванова"
              />
              <Input
                label="Имя"
                value={form.first_name}
                onChange={(e) => setForm({ ...form, first_name: e.target.value })}
                placeholder="Мария"
              />
              <Input
                label="Отчество"
                value={form.patronymic}
                onChange={(e) => setForm({ ...form, patronymic: e.target.value })}
                placeholder="Петровна"
              />
            </div>
            <Input
              label="Телефон"
              type="tel"
              value={form.phone}
              onChange={(e) => setForm({ ...form, phone: e.target.value })}
              placeholder="+7 ..."
              hint="Для звонка или уточнения записи"
            />
            <Button size="sm" onClick={handleSave} loading={saving}>
              Сохранить карточку
            </Button>
          </section>

          {stats && (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <StatBox label="Визитов" value={stats.total_visits} />
              <StatBox label="Выручка" value={formatPrice(stats.total_revenue)} />
              <StatBox label="Средний чек" value={formatPrice(stats.average_check)} />
              <StatBox label="Предстоящие" value={stats.upcoming_visits} />
              {stats.last_visit && (
                <StatBox label="Последний визит" value={formatDate(stats.last_visit)} />
              )}
              {stats.favorite_service && (
                <div className="col-span-2 sm:col-span-4">
                  <StatBox label="Частая услуга" value={stats.favorite_service} />
                </div>
              )}
            </div>
          )}

          <div>
            <Textarea
              label="Заметки о клиенте"
              value={form.notes}
              onChange={(e) => setForm({ ...form, notes: e.target.value })}
              rows={3}
              placeholder="Аллергии, предпочтения, важные детали..."
            />
          </div>

          <div>
            <h3 className="text-sm font-semibold text-ink mb-3">История визитов</h3>
            {appointments.length === 0 ? (
              <p className="text-sm text-ink-muted">Записей нет</p>
            ) : (
              <ul className="divide-y divide-slate-100 rounded-xl border border-slate-100 overflow-hidden">
                {appointments.map((apt) => {
                  const st = STATUS_LABELS[apt.status] || STATUS_LABELS.confirmed;
                  return (
                    <li key={apt.id} className="px-4 py-3 bg-white hover:bg-slate-50/80">
                      <div className="flex flex-wrap items-start justify-between gap-2">
                        <div>
                          <p className="font-medium text-ink">{apt.service_name}</p>
                          <p className="text-xs text-ink-muted mt-0.5">
                            {formatDateTime(apt.appointment_time)}
                            {apt.salon_master_name && ` · ${apt.salon_master_name}`}
                          </p>
                          {apt.client_notes && (
                            <p className="text-xs text-ink-secondary mt-1">{apt.client_notes}</p>
                          )}
                        </div>
                        <div className="text-right shrink-0">
                          <Badge tone={st.tone}>{st.label}</Badge>
                          {apt.service_price != null && (
                            <p className="text-sm font-semibold text-primary mt-1">{formatPrice(apt.service_price)}</p>
                          )}
                        </div>
                      </div>
                    </li>
                  );
                })}
              </ul>
            )}
          </div>
        </div>
      )}
    </Modal>
  );
}
