export default function TeamMasterSelect({ masters, value, onChange, label = 'Мастер' }) {
  if (!masters?.length) return null;
  if (masters.length === 1) {
    return (
      <p className="text-sm text-ink-secondary mb-4">
        {label}: <span className="font-semibold text-ink">{masters[0].name}</span>
      </p>
    );
  }
  return (
    <div className="mb-4">
      <label className="block text-sm font-medium text-ink mb-2">{label}</label>
      <div className="flex flex-wrap gap-2">
        {masters.filter((m) => m.is_active !== false).map((m) => (
          <button
            key={m.id}
            type="button"
            onClick={() => onChange(m.id)}
            className={`chip ${value === m.id ? 'chip-active' : 'chip-inactive'}`}
          >
            {m.name}
          </button>
        ))}
      </div>
    </div>
  );
}
