import { useState } from 'react';
import axios from 'axios';
import Button from '../ui/Button';
import Textarea from '../ui/Textarea';
import { formatDate } from '../../lib/format';

function Stars({ value, onChange }) {
  return (
    <div className="flex gap-1">
      {[1, 2, 3, 4, 5].map((n) => (
        <button
          key={n}
          type="button"
          onClick={() => onChange?.(n)}
          className={`text-2xl ${n <= value ? 'text-amber-500' : 'text-slate-300'}`}
        >
          ★
        </button>
      ))}
    </div>
  );
}

function StarsRead({ value }) {
  return <span className="text-amber-500">{'★'.repeat(value)}{'☆'.repeat(5 - value)}</span>;
}

export default function ClientReviewsPanel({
  reviews,
  reviewSummary,
  masterId,
  clientAuth,
  formData,
  onSubmitted
}) {
  const [rating, setRating] = useState(5);
  const [body, setBody] = useState('');
  const [sending, setSending] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!clientAuth) return;
    setSending(true);
    try {
      const payload = {
        masterId,
        channel: clientAuth.channel,
        userId: clientAuth.userId,
        rating,
        body,
        clientName: formData?.name
      };
      if (clientAuth.channel === 'telegram') payload.telegramUserId = clientAuth.userId;
      else payload.maxUserId = clientAuth.userId;
      await axios.post('/api/client/reviews', payload);
      setBody('');
      onSubmitted?.();
      alert('Спасибо! Отзыв отправлен на модерацию — появится на сайте после проверки салоном.');
    } catch (err) {
      alert(err.response?.data?.error || 'Не удалось отправить отзыв');
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="space-y-6">
      {reviewSummary?.count > 0 && (
        <p className="text-lg font-bold text-ink">
          <span className="text-amber-500">★ {reviewSummary.average || '—'}</span>
          <span className="text-sm font-normal text-ink-muted ml-2">({reviewSummary.count} отзывов)</span>
        </p>
      )}

      {reviews?.length > 0 ? (
        <ul className="space-y-3">
          {reviews.map((r) => (
            <li key={r.id} className="rounded-xl border border-slate-100 p-4">
              <StarsRead value={r.rating} />
              <p className="font-medium text-sm mt-1">{r.client_name || 'Клиент'}</p>
              {r.body && <p className="text-sm text-ink-secondary mt-1">{r.body}</p>}
              {r.salon_reply && (
                <p className="text-sm mt-2 bg-primary/5 rounded-lg px-3 py-2">
                  <span className="font-medium">Ответ салона: </span>{r.salon_reply}
                </p>
              )}
              <p className="text-xs text-ink-muted mt-2">{formatDate(r.created_at)}</p>
            </li>
          ))}
        </ul>
      ) : (
        <p className="text-sm text-ink-muted">Отзывов пока нет — будьте первым!</p>
      )}

      <form onSubmit={handleSubmit} className="rounded-xl border border-primary/20 bg-primary/5 p-4 space-y-3">
        <h3 className="font-semibold text-ink">Оставить отзыв</h3>
        <Stars value={rating} onChange={setRating} />
        <Textarea value={body} onChange={(e) => setBody(e.target.value)} rows={3} placeholder="Расскажите о визите..." />
        <Button type="submit" loading={sending} className="w-full">Отправить</Button>
      </form>
    </div>
  );
}
