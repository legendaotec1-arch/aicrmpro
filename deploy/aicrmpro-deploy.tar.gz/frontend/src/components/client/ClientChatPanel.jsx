import { useEffect, useState, useRef } from 'react';
import axios from 'axios';
import Button from '../ui/Button';
import Input from '../ui/Input';
import { formatDateTime } from '../../lib/format';

export default function ClientChatPanel({ masterId, clientAuth, formData }) {
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  const bottomRef = useRef(null);

  const load = async () => {
    if (!clientAuth) return;
    try {
      const res = await axios.get(
        `/api/client/${masterId}/chat?channel=${clientAuth.channel}&userId=${encodeURIComponent(clientAuth.userId)}`
      );
      setMessages(res.data.messages || []);
      setTimeout(() => bottomRef.current?.scrollIntoView({ behavior: 'smooth' }), 50);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    load();
    const t = setInterval(load, 15000);
    return () => clearInterval(t);
  }, [masterId, clientAuth]);

  const send = async (e) => {
    e.preventDefault();
    if (!text.trim() || !clientAuth) return;
    setSending(true);
    try {
      await axios.post(`/api/client/${masterId}/chat`, {
        channel: clientAuth.channel,
        userId: clientAuth.userId,
        maxUserId: clientAuth.channel === 'max' ? clientAuth.userId : undefined,
        telegramUserId: clientAuth.channel === 'telegram' ? clientAuth.userId : undefined,
        body: text.trim(),
        name: formData?.name
      });
      setText('');
      await load();
    } catch (err) {
      alert(err.response?.data?.error || 'Ошибка отправки');
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="flex flex-col min-h-[400px]">
      <h2 className="text-lg font-bold text-ink mb-2">Чат с салоном</h2>
      <p className="text-sm text-ink-muted mb-4">Общий диалог — ответ придёт в MAX или Telegram</p>
      <div className="flex-1 overflow-y-auto space-y-3 mb-4 max-h-[320px] pr-1">
        {messages.length === 0 ? (
          <p className="text-sm text-ink-muted text-center py-8">Напишите первым — салон ответит в мессенджер</p>
        ) : (
          messages.map((m) => (
            <div key={m.id} className={`flex ${m.sender_type === 'client' ? 'justify-end' : 'justify-start'}`}>
              <div
                className={`max-w-[85%] rounded-2xl px-4 py-2 text-sm ${
                  m.sender_type === 'client'
                    ? 'bg-primary text-white'
                    : 'bg-slate-100 text-ink'
                }`}
              >
                <p>{m.body}</p>
                <p className={`text-[10px] mt-1 ${m.sender_type === 'client' ? 'text-white/70' : 'text-ink-muted'}`}>
                  {formatDateTime(m.created_at)}
                </p>
              </div>
            </div>
          ))
        )}
        <div ref={bottomRef} />
      </div>
      <form onSubmit={send} className="flex gap-2">
        <Input
          className="flex-1"
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Сообщение..."
        />
        <Button type="submit" loading={sending} disabled={!text.trim()}>
          →
        </Button>
      </form>
    </div>
  );
}
