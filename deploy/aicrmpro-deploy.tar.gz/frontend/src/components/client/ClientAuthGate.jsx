import Button from '../ui/Button';
import MaxLogo from '../brand/MaxLogo';
import { IconTelegram } from '../brand/SocialBrandIcons';
import MessengerLabel from '../brand/MessengerLabel';

export default function ClientAuthGate({
  master,
  telegramBotUsername,
  telegramBotDeepLink,
  maxBotDeepLink,
}) {
  const salonName = master?.salon_name || master?.name || 'мастеру';

  return (
    <div className="card-light max-w-md w-full mx-auto p-8 text-center">
      <h2 className="text-xl font-bold text-ink">Запись к {salonName}</h2>
      <p className="mt-2 text-sm text-ink-secondary leading-relaxed">
        Войдите, чтобы записаться и получать напоминания в мессенджере
      </p>

      <div className="mt-8 space-y-4">
        <div className="rounded-2xl border border-sky-100 bg-sky-50/50 p-5">
          <div className="flex items-center justify-center gap-2 mb-3">
            <IconTelegram className="h-5 w-5 text-sky-600" />
            <span className="font-semibold text-ink text-sm">Telegram</span>
          </div>
          <p className="text-xs text-ink-muted mb-4">
            Откроется бот — нажмите «Записаться» и вернётесь на эту страницу
          </p>
          {telegramBotDeepLink ? (
            <a href={telegramBotDeepLink} className="block">
              <Button type="button" className="w-full gap-2">
                <IconTelegram className="h-4 w-4" />
                Продолжить в Telegram
              </Button>
            </a>
          ) : (
            <p className="text-xs text-amber-700">Вход через Telegram временно недоступен</p>
          )}
          {telegramBotUsername && (
            <p className="text-[11px] text-ink-muted mt-2">@{telegramBotUsername}</p>
          )}
        </div>

        <div className="rounded-2xl border border-violet-100 bg-violet-50/50 p-5">
          <div className="flex items-center justify-center gap-2 mb-3">
            <MaxLogo className="h-5 w-5" />
            <span className="font-semibold text-ink text-sm">MAX</span>
          </div>
          <p className="text-xs text-ink-muted mb-4">
            Откроется бот — нажмите «Записаться» и вернётесь на эту страницу
          </p>
          {maxBotDeepLink ? (
            <a href={maxBotDeepLink} className="block">
              <Button type="button" className="w-full gap-2" variant="secondary">
                <MaxLogo className="h-4 w-4" />
                Продолжить в MAX
              </Button>
            </a>
          ) : (
            <p className="text-xs text-amber-700">MAX-бот не настроен</p>
          )}
        </div>
      </div>

      <p className="mt-6 text-xs text-ink-muted flex items-center justify-center gap-1 flex-wrap">
        Напоминания приходят в <MessengerLabel channel="telegram" size="xs" /> или <MessengerLabel channel="max" size="xs" />
      </p>
    </div>
  );
}
