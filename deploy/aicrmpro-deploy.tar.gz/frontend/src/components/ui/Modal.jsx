import { useEffect } from 'react';
import Button from './Button';

export default function Modal({ open, onClose, title, description, children, footer, size = 'md' }) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e) => e.key === 'Escape' && onClose();
    document.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
    };
  }, [open, onClose]);

  if (!open) return null;

  const widths = { sm: 'max-w-md', md: 'max-w-lg', lg: 'max-w-2xl' };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm" onClick={onClose} aria-hidden />
      <div
        className={`relative w-full ${widths[size]} animate-slide-up rounded-3xl bg-white shadow-elevated border border-slate-200/80 max-h-[90vh] overflow-y-auto`}
        role="dialog"
        aria-modal="true"
      >
        <div className="p-6 border-b border-slate-100">
          <h3 className="font-display text-xl font-semibold text-ink">{title}</h3>
          {description && <p className="mt-1 text-sm text-ink-secondary">{description}</p>}
        </div>
        <div className="p-6">{children}</div>
        {footer !== undefined ? (
          <div className="px-6 pb-6 flex gap-3 justify-end">{footer}</div>
        ) : (
          <div className="px-6 pb-6">
            <Button variant="secondary" onClick={onClose} className="w-full sm:w-auto">
              Закрыть
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
