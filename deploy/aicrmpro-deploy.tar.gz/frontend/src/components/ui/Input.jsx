export default function Input({ label, hint, error, className = '', ...props }) {
  return (
    <div className={className}>
      {label && <label className="label-field">{label}</label>}
      <input className={`input-field ${error ? 'border-rose-300 focus:border-rose-400 focus:ring-rose-500/15' : ''}`} {...props} />
      {hint && !error && <p className="mt-1 text-xs text-ink-muted">{hint}</p>}
      {error && <p className="mt-1 text-xs text-rose-600">{error}</p>}
    </div>
  );
}
