export default function Card({ children, className = '', padding = true, dark = false }) {
  return (
    <div
      className={`rounded-2xl ${padding ? 'p-5' : ''} ${
        dark
          ? 'border border-dark-border bg-dark-card shadow-card-dark'
          : 'border border-slate-100 bg-white shadow-card'
      } ${className}`}
    >
      {children}
    </div>
  );
}

export function CardHeader({ title, description, action }) {
  return (
    <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
      <div>
        <h2 className="font-display text-base font-semibold text-ink">{title}</h2>
        {description && <p className="mt-0.5 text-sm text-ink-secondary">{description}</p>}
      </div>
      {action}
    </div>
  );
}
