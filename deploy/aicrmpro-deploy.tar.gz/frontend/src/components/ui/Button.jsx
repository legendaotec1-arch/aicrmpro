const sizes = {
  sm: 'px-3 py-1.5 text-xs rounded-lg',
  md: 'px-4 py-2.5 text-sm rounded-xl',
  lg: 'px-6 py-3.5 text-sm rounded-xl'
};

export default function Button({
  children,
  variant = 'primary',
  size = 'md',
  className = '',
  loading = false,
  disabled,
  light = false,
  ...props
}) {
  const variants = {
    primary:
      'bg-primary text-white shadow-md shadow-primary/25 hover:bg-primary-hover focus-visible:ring-primary/40',
    secondary:
      'bg-white text-ink border border-slate-200 hover:bg-slate-50 shadow-sm',
    ghost: light
      ? 'text-slate-300 hover:bg-white/10 hover:text-white'
      : 'text-ink-secondary hover:bg-slate-100 hover:text-ink',
    danger: 'bg-rose-50 text-rose-600 border border-rose-200 hover:bg-rose-100',
    soft: 'bg-primary/10 text-primary hover:bg-primary/20',
    dark: 'bg-dark-card text-white border border-dark-border hover:bg-slate-800'
  };

  return (
    <button
      type="button"
      disabled={disabled || loading}
      className={`inline-flex items-center justify-center gap-2 font-semibold transition focus-visible:outline-none focus-visible:ring-4 disabled:cursor-not-allowed disabled:opacity-50 ${variants[variant] || variants.primary} ${sizes[size]} ${className}`}
      {...props}
    >
      {loading && (
        <span className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" />
      )}
      {children}
    </button>
  );
}
