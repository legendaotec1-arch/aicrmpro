import MessengerLabel from '../brand/MessengerLabel';

const tones = {
  success: 'bg-success-soft text-emerald-700',
  danger: 'bg-rose-50 text-rose-700',
  warning: 'bg-warning-soft text-amber-800',
  neutral: 'bg-slate-100 text-slate-600',
  brand: 'bg-primary/10 text-primary',
  primary: 'bg-primary text-white',
  max: 'bg-slate-100 text-slate-800 border border-slate-200',
  telegram: 'bg-sky-100 text-sky-700'
};

export default function Badge({ children, tone = 'neutral', className = '' }) {
  const isMessenger = tone === 'max' || tone === 'telegram';

  return (
    <span
      className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ${tones[tone]} ${className}`}
    >
      {isMessenger ? (
        <MessengerLabel channel={tone} size="xs" />
      ) : (
        children
      )}
    </span>
  );
}
