import { Link } from 'react-router-dom';
import { Check, Crown, Infinity, Sparkles, Wallet } from 'lucide-react';
import Button from '../ui/Button';

const FREE_FEATURES = [
  'Онлайн-запись и персональная страница',
  'Аналитика, выручка и статистика',
  'Портфолио и прайс-листы',
  'Расписание и напоминания клиентам',
  'Ссылки для Telegram, MAX, ВК и Instagram*',
  'Рассылка и база клиентов'
];

const PLANS = [
  {
    id: 'per-booking',
    badge: 'Старт без риска',
    title: 'За запись',
    price: '30 ₽',
    period: 'за каждого клиента, который записался через сервис',
    description:
      'Идеально, чтобы попробовать без обязательств. Подписки нет — вы не платите ни копейки, пока нет реальных записей.',
    highlights: [
      'Абонентская плата — 0 ₽',
      '30 ₽ — когда клиент оформил запись онлайн (не за визит)',
      'Нет клиентов — нет платежей'
    ],
    Icon: Wallet,
    accent: 'border-slate-200 bg-white',
    iconVariant: 'soft'
  },
  {
    id: 'unlimited',
    badge: 'Популярный выбор',
    title: 'Безлимит',
    price: '1 500 ₽',
    period: 'на 30 дней · записей без ограничений',
    description:
      'Один платёж — и вы спокойно принимаете любой поток клиентов. Выгодно, если у вас от ~50 записей в месяц и больше.',
    highlights: [
      'Неограниченное число записей',
      'Автопродление каждые 30 дней (отключение в кабинете)',
      'Все функции системы включены'
    ],
    Icon: Infinity,
    accent: 'border-primary/40 bg-gradient-to-b from-violet-50 to-white ring-2 ring-primary/20',
    iconVariant: 'gradient',
    featured: true
  }
];

export default function PricingSection() {
  return (
    <section id="pricing" className="scroll-mt-24 px-4 py-16 lg:px-8 lg:py-24 bg-gradient-to-b from-white via-[#faf8ff] to-white">
      <div className="mx-auto max-w-7xl">
        <div className="text-center max-w-3xl mx-auto">
          <span className="inline-flex items-center gap-2 rounded-full border border-emerald-200 bg-emerald-50 px-4 py-1.5 text-sm font-semibold text-emerald-700">
            <Sparkles className="h-4 w-4" strokeWidth={2} />
            Честные тарифы без скрытых платежей
          </span>
          <h2 className="mt-5 text-3xl font-black text-slate-900 sm:text-4xl lg:text-[2.5rem] leading-tight">
            Платите за результат,
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-violet-600 to-blue-500">
              {' '}
              а не за воздух
            </span>
          </h2>
          <p className="mt-4 text-base sm:text-lg text-slate-600 leading-relaxed">
            <strong className="font-semibold text-slate-800">MasterClient45 бесплатен для входа.</strong>{' '}
            Мы не берём абонентскую плату «просто так». Вы платите, когда сервис приносит пользу — когда клиент
            записался к вам через нашу систему.
          </p>
        </div>

        <div className="mt-12 grid gap-6 lg:grid-cols-2 lg:gap-8">
          {PLANS.map((plan) => (
            <article
              key={plan.id}
              className={`relative flex flex-col rounded-[1.75rem] border p-6 sm:p-8 shadow-lg shadow-violet-100/50 ${plan.accent}`}
            >
              {plan.featured && (
                <span className="absolute -top-3 left-1/2 -translate-x-1/2 inline-flex items-center gap-1.5 rounded-full bg-primary px-4 py-1 text-xs font-bold text-white shadow-md">
                  <Crown className="h-3.5 w-3.5" strokeWidth={2} />
                  {plan.badge}
                </span>
              )}
              {!plan.featured && (
                <span className="inline-flex w-fit rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-600 mb-4">
                  {plan.badge}
                </span>
              )}

              <div className="flex items-start gap-4">
                <div
                  className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl ${
                    plan.iconVariant === 'gradient'
                      ? 'bg-gradient-to-br from-violet-600 to-blue-500 text-white shadow-lg shadow-primary/25'
                      : 'bg-violet-50 text-primary'
                  }`}
                >
                  <plan.Icon className="h-6 w-6" strokeWidth={1.75} />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-slate-900">{plan.title}</h3>
                  <p className="mt-3">
                    <span className="text-4xl sm:text-5xl font-black text-slate-900 tracking-tight">{plan.price}</span>
                  </p>
                  <p className="mt-1 text-sm text-slate-500">{plan.period}</p>
                </div>
              </div>

              <p className="mt-5 text-sm text-slate-600 leading-relaxed">{plan.description}</p>

              <ul className="mt-5 space-y-2.5 flex-1">
                {plan.highlights.map((item) => (
                  <li key={item} className="flex items-start gap-2.5 text-sm text-slate-700">
                    <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-emerald-100 text-emerald-600">
                      <Check className="h-3 w-3" strokeWidth={3} />
                    </span>
                    {item}
                  </li>
                ))}
              </ul>

              <Link to="/register" className="mt-8 block">
                <Button
                  className="w-full"
                  variant={plan.featured ? 'primary' : 'secondary'}
                  size="lg"
                >
                  {plan.featured ? 'Подключить безлимит' : 'Начать с оплаты за запись'}
                </Button>
              </Link>
            </article>
          ))}
        </div>

        <div className="mt-12 rounded-[1.75rem] border border-violet-100 bg-white p-6 sm:p-8 shadow-sm">
          <div className="flex flex-col gap-6 lg:flex-row lg:items-start lg:justify-between">
            <div className="lg:max-w-md">
              <h3 className="text-xl font-bold text-slate-900 sm:text-2xl">
                Все функции системы — бесплатно в любом тарифе
              </h3>
              <p className="mt-2 text-sm sm:text-base text-slate-600 leading-relaxed">
                Мы не продаём «дополнительные модули». Аналитика, портфолио, прайсы, боты и инструменты роста —
                всегда в вашем распоряжении. Тариф — только про количество записей, не про доступ к возможностям.
              </p>
            </div>
            <ul className="grid gap-2.5 sm:grid-cols-2 lg:gap-x-8 lg:flex-1">
              {FREE_FEATURES.map((feature) => (
                <li key={feature} className="flex items-center gap-2 text-sm text-slate-700">
                  <Check className="h-4 w-4 shrink-0 text-primary" strokeWidth={2.5} />
                  {feature}
                </li>
              ))}
            </ul>
          </div>
        </div>

        <p className="mt-8 text-center text-xs sm:text-sm text-slate-400 max-w-2xl mx-auto leading-relaxed">
          По тарифу «За запись» с баланса списывается 30 ₽, когда клиент оформил запись через MasterClient45. Посещение
          визита мы не отслеживаем — оплата именно за онлайн-запись. Тариф «Безлимит» действует 30 календарных дней с
          момента оплаты.
        </p>
      </div>
    </section>
  );
}
