export default function Logo({ className = '', light = false }) {
  return (
    <div className={`flex items-center gap-2.5 ${className}`}>
      <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary-gradient shadow-glow">
        <span className="text-sm font-black text-white" aria-hidden>
          M
        </span>
      </div>
      <span className={`font-display text-lg font-bold tracking-tight ${light ? 'text-white' : 'text-ink'}`}>
        Master<span className="text-primary">Client45</span>
      </span>
    </div>
  );
}
