import { Link } from 'react-router-dom';
import Logo from '../brand/Logo';
import ChannelLinks from '../landing/ChannelLinks';

export default function AuthLayout({ children, title, subtitle }) {
  return (
    <div className="min-h-screen flex bg-hero-gradient">
      <div className="hidden lg:flex lg:w-1/2 flex-col justify-between p-12 border-r border-white/10">
        <Logo light />
        <div>
          <h2 className="text-4xl font-black text-white leading-tight">
            Управляйте
            <br />
            <span className="text-primary-light">записями</span>
            <br />
            как профи
          </h2>
          <p className="mt-4 text-slate-400 max-w-sm">
            Кабинет мастера и страница записи. Одна ссылка — Telegram, MAX, ВКонтакте, Instagram*.
          </p>
          <ChannelLinks variant="strip" light align="left" className="mt-8" subtitle="Каналы для клиентов" />
        </div>
        <div className="text-xs text-slate-600 space-y-2">
          <p>© MasterClient45</p>
          <p className="flex flex-wrap gap-x-3 gap-y-1">
            <Link to="/legal/offer" className="hover:text-slate-400 transition">
              Оферта
            </Link>
            <Link to="/legal/privacy" className="hover:text-slate-400 transition">
              Персональные данные
            </Link>
            <Link to="/legal/payment" className="hover:text-slate-400 transition">
              Оплата и возврат
            </Link>
          </p>
        </div>
      </div>

      <div className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-md animate-slide-up">
          <div className="lg:hidden mb-8 flex justify-center">
            <Logo light />
          </div>
          <div className="rounded-3xl bg-white p-8 shadow-elevated border border-slate-100">
            <div className="mb-8 text-center lg:text-left">
              <h1 className="text-2xl font-bold text-ink">{title}</h1>
              <p className="mt-1 text-ink-secondary text-sm">{subtitle}</p>
            </div>
            {children}
          </div>
          <p className="mt-6 text-center">
            <Link to="/" className="text-sm text-slate-400 hover:text-white transition">
              ← На главную
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
