import {
  Bell,
  Calendar,
  Clock,
  BarChart3,
  Home,
  Images,
  Link2,
  LogOut,
  MessageCircle,
  RefreshCw,
  Settings,
  Sparkles,
  Star,
  UserRound,
  Users
} from 'lucide-react';
import Logo from '../brand/Logo';
import Button from '../ui/Button';
import { mediaUrl } from '../../lib/media';

const NAV = [
  { id: 'overview', label: 'Главная', Icon: Home },
  { id: 'analytics', label: 'Аналитика', Icon: BarChart3 },
  { id: 'appointments', label: 'Записи', Icon: Calendar },
  { id: 'clients', label: 'Клиенты', Icon: Users },
  { id: 'chat', label: 'Чат', Icon: MessageCircle },
  { id: 'reviews', label: 'Отзывы', Icon: Star },
  { id: 'invites', label: 'Повтор', Icon: RefreshCw },
  { id: 'team', label: 'Мастера', Icon: UserRound },
  { id: 'prices', label: 'Услуги', Icon: Sparkles },
  { id: 'portfolio', label: 'Портфолио', Icon: Images },
  { id: 'schedule', label: 'Расписание', Icon: Clock },
  { id: 'links', label: 'Ссылки MAX / TG', Icon: Link2 },
  { id: 'profile', label: 'Настройки', Icon: Settings }
];

export default function DashboardLayout({
  profile,
  activeSection,
  onSectionChange,
  onLogout,
  navBadges = {},
  children
}) {
  const firstName = profile?.name?.split(' ')[0] || 'Мастер';
  const avatarLetter = (profile?.name?.[0] || 'М').toUpperCase();
  const avatarSrc = profile?.logo_url ? mediaUrl(profile.logo_url) : null;

  const openSettings = () => onSectionChange('profile');

  return (
    <div className="flex min-h-screen bg-slate-100">
      <aside className="hidden lg:flex w-64 flex-col bg-dark shrink-0 border-r border-dark-border">
        <div className="p-5 border-b border-dark-border">
          <Logo light />
        </div>
        <nav className="flex-1 p-3 space-y-0.5 overflow-y-auto">
          {NAV.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => onSectionChange(item.id)}
              className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition ${
                activeSection === item.id
                  ? 'bg-primary text-white shadow-lg shadow-primary/30'
                  : 'text-slate-400 hover:bg-white/5 hover:text-white'
              }`}
            >
              <item.Icon className="h-[18px] w-[18px] shrink-0" strokeWidth={1.75} />
              <span className="flex-1 text-left">{item.label}</span>
              {item.id === 'chat' && navBadges.chatUnread > 0 && (
                <span className="min-w-[18px] h-[18px] px-1 rounded-full bg-white text-primary text-xs font-bold flex items-center justify-center">
                  {navBadges.chatUnread > 99 ? '99+' : navBadges.chatUnread}
                </span>
              )}
              {item.id === 'reviews' && navBadges.reviewsPending > 0 && (
                <span className="min-w-[18px] h-[18px] px-1 rounded-full bg-amber-400 text-amber-950 text-xs font-bold flex items-center justify-center">
                  {navBadges.reviewsPending > 99 ? '99+' : navBadges.reviewsPending}
                </span>
              )}
            </button>
          ))}
        </nav>
        <div className="p-4 border-t border-dark-border">
          <Button variant="ghost" light className="w-full justify-start gap-2" onClick={onLogout}>
            <LogOut className="h-4 w-4" strokeWidth={1.75} />
            Выйти
          </Button>
        </div>
      </aside>

      <div className="flex-1 flex flex-col min-w-0">
        <header className="sticky top-0 z-30 bg-white border-b border-slate-200 px-4 py-4 lg:px-8">
          <div className="flex items-center justify-between gap-4">
            <div className="lg:hidden">
              <Logo />
            </div>
            <div className="hidden lg:block">
              <h1 className="text-xl font-bold text-ink">
                Добро пожаловать, {firstName}!
              </h1>
              <p className="text-sm text-ink-secondary">{profile?.salon_name || 'Ваш кабинет'}</p>
            </div>
            <div className="flex items-center gap-3 ml-auto">
              <button
                type="button"
                className="hidden sm:flex h-10 w-10 items-center justify-center rounded-xl bg-slate-100 text-slate-500 hover:bg-slate-200 hover:text-slate-700 transition"
                aria-label="Уведомления"
              >
                <Bell className="h-5 w-5" strokeWidth={1.75} />
              </button>
              <button
                type="button"
                onClick={openSettings}
                title="Настройки профиля"
                aria-label="Открыть настройки"
                className={`relative flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-full border-2 transition focus:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 ${
                  activeSection === 'profile'
                    ? 'border-primary ring-2 ring-primary/30'
                    : 'border-slate-200 hover:border-primary hover:shadow-md'
                }`}
              >
                {avatarSrc ? (
                  <img src={avatarSrc} alt="" className="h-full w-full object-cover" />
                ) : (
                  <span className="flex h-full w-full items-center justify-center bg-primary-gradient text-sm font-bold text-white">
                    {avatarLetter}
                  </span>
                )}
              </button>
            </div>
          </div>
          <nav className="flex lg:hidden gap-1 mt-4 overflow-x-auto pb-1 -mx-1">
            {NAV.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => onSectionChange(item.id)}
                className={`chip text-xs relative ${activeSection === item.id ? 'chip-active' : 'chip-inactive'}`}
              >
                {item.label}
                {item.id === 'chat' && navBadges.chatUnread > 0 && ' •'}
                {item.id === 'reviews' && navBadges.reviewsPending > 0 && ' •'}
              </button>
            ))}
          </nav>
        </header>

        <main className="flex-1 p-4 lg:p-8 animate-fade-in overflow-auto">{children}</main>
      </div>
    </div>
  );
}

export function StatCard({ label, value, hint, trend, accent }) {
  return (
    <div className="card-light">
      <p className="text-xs font-medium text-ink-muted uppercase tracking-wide">{label}</p>
      <div className="mt-2 flex items-end justify-between gap-2">
        <p className={`font-display text-3xl font-bold ${accent || 'text-ink'}`}>{value}</p>
        {trend && (
          <span className="text-xs font-semibold text-success bg-success-soft px-2 py-0.5 rounded-full mb-1">
            {trend}
          </span>
        )}
      </div>
      {hint && <p className="mt-1 text-xs text-ink-secondary">{hint}</p>}
    </div>
  );
}

export function MiniChart({ data }) {
  const max = Math.max(...data, 1);
  const days = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'];
  return (
    <div className="flex items-end justify-between gap-2 h-32 pt-4">
      {data.map((v, i) => (
        <div key={i} className="flex-1 flex flex-col items-center gap-2">
          <div
            className="w-full rounded-t-lg bg-primary/80 min-h-[4px] transition-all"
            style={{ height: `${(v / max) * 100}%` }}
          />
          <span className="text-[10px] text-ink-muted font-medium">{days[i]}</span>
        </div>
      ))}
    </div>
  );
}
