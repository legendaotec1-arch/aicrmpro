import { useState, useEffect, useCallback, useMemo } from 'react';
import { useParams, useSearchParams } from 'react-router-dom';
import Calendar from 'react-calendar';
import 'react-calendar/dist/Calendar.css';
import axios from 'axios';
import {
  CalendarDays,
  Clock,
  Home,
  Image as ImageIcon,
  ListChecks,
  MapPin,
  MessageCircle,
  Phone,
  Play,
  Star,
  UserRound
} from 'lucide-react';
import Logo from '../components/brand/Logo';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';
import Badge from '../components/ui/Badge';
import Modal from '../components/ui/Modal';
import { PageLoader } from '../components/ui/Spinner';
import MessengerLabel from '../components/brand/MessengerLabel';
import ClientAuthGate from '../components/client/ClientAuthGate';
import ClientReviewsPanel from '../components/client/ClientReviewsPanel';
import ClientChatPanel from '../components/client/ClientChatPanel';
import { formatDateTime, formatPrice } from '../lib/format';
import { mediaUrl } from '../lib/media';
import { getClientSession, setClientSession, clearClientSession } from '../lib/clientSession';

const CLIENT_TABS = [
  { id: 'home', label: 'Главная', Icon: Home },
  { id: 'booking', label: 'Запись', Icon: CalendarDays },
  { id: 'appointments', label: 'Мои записи', Icon: ListChecks },
  { id: 'chat', label: 'Чат', Icon: MessageCircle },
  { id: 'reviews', label: 'Отзывы', Icon: Star }
];

function buildMapUrl(master) {
  if (master?.latitude && master?.longitude) {
    const ll = `${master.longitude},${master.latitude}`;
    return `https://yandex.ru/map-widget/v1/?ll=${encodeURIComponent(ll)}&z=16&pt=${encodeURIComponent(`${ll},pm2rdm`)}`;
  }
  if (master?.yandex_maps_link) return master.yandex_maps_link;
  if (master?.address) return `https://yandex.ru/map-widget/v1/?text=${encodeURIComponent(master.address)}`;
  return null;
}

function MediaPreview({ item, className = '' }) {
  if (item.media_type === 'video') {
    return <video src={mediaUrl(item.video_url)} className={`h-full w-full object-cover ${className}`} muted playsInline />;
  }
  if (item.media_type === 'external_video') {
    return (
      <div className={`flex h-full w-full items-center justify-center bg-slate-900 text-white ${className}`}>
        <Play className="h-9 w-9" />
      </div>
    );
  }
  return <img src={mediaUrl(item.image_url)} alt={item.title || ''} className={`h-full w-full object-cover ${className}`} />;
}

export default function ClientPage() {
  const { masterId } = useParams();
  const [searchParams, setSearchParams] = useSearchParams();
  const [master, setMaster] = useState(null);
  const [bookingConfig, setBookingConfig] = useState(null);
  const [portfolio, setPortfolio] = useState([]);
  const [priceList, setPriceList] = useState([]);
  const [teamMasters, setTeamMasters] = useState([]);
  const [priceGroups, setPriceGroups] = useState([]);
  const [selectedSalonMaster, setSelectedSalonMaster] = useState(null);
  const [reviews, setReviews] = useState([]);
  const [reviewSummary, setReviewSummary] = useState({ count: 0, average: null });
  const [activeTab, setActiveTab] = useState('home');
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [availableSlots, setAvailableSlots] = useState([]);
  const [selectedSlot, setSelectedSlot] = useState(null);
  const [selectedService, setSelectedService] = useState(null);
  const [step, setStep] = useState('pick');
  const [formData, setFormData] = useState({ name: '', phone: '' });
  const [loading, setLoading] = useState(true);
  const [booking, setBooking] = useState(false);
  const [clientAuth, setClientAuth] = useState(null);
  const [authChecked, setAuthChecked] = useState(false);
  const [rescheduleId, setRescheduleId] = useState(null);
  const [rescheduleLoading, setRescheduleLoading] = useState(false);
  const [appointments, setAppointments] = useState([]);
  const [appointmentsLoading, setAppointmentsLoading] = useState(false);
  const [mediaIndex, setMediaIndex] = useState(null);

  const resolveAuthFromUrl = useCallback(() => {
    const ch = searchParams.get('ch');
    const uid = searchParams.get('uid');
    const tab = searchParams.get('tab');
    const reschedule = searchParams.get('reschedule');

    if (tab && CLIENT_TABS.some((item) => item.id === tab)) setActiveTab(tab);
    if (reschedule) {
      setRescheduleId(reschedule);
      setActiveTab('booking');
      setStep('pick');
    }

    if (uid && (ch === 'max' || ch === 'telegram')) {
      const session = { channel: ch, userId: uid };
      setClientSession(masterId, session);
      setClientAuth(session);
      setSearchParams({}, { replace: true });
      return session;
    }

    return getClientSession(masterId);
  }, [masterId, searchParams, setSearchParams]);

  const loadMasterData = useCallback(async () => {
    try {
      setLoading(true);
      const res = await axios.get(`/api/master/${masterId}`);
      const groups = res.data.priceGroups || [];
      const masters = res.data.teamMasters || [];
      const flat = res.data.priceList || groups.flatMap((g) => g.services);
      const firstMaster = masters[0] || null;
      const firstServices = groups.find((g) => g.master.id === firstMaster?.id)?.services || flat;

      setMaster(res.data.master);
      setBookingConfig(res.data.booking || null);
      setPortfolio(res.data.portfolio || []);
      setPriceGroups(groups);
      setTeamMasters(masters);
      setPriceList(flat);
      setSelectedSalonMaster((prev) => prev || firstMaster);
      if (!selectedService && firstServices?.length === 1) setSelectedService(firstServices[0]);
      setReviewSummary(res.data.reviewSummary || { count: 0, average: null });
      setReviews(res.data.reviews || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [masterId, selectedService]);

  const loadAppointments = useCallback(async () => {
    if (!clientAuth) return;
    setAppointmentsLoading(true);
    try {
      const res = await axios.get(`/api/client/my/${encodeURIComponent(clientAuth.userId)}`, {
        params: { channel: clientAuth.channel, masterId }
      });
      setAppointments(res.data || []);
    } catch (err) {
      console.error(err);
    } finally {
      setAppointmentsLoading(false);
    }
  }, [clientAuth]);

  useEffect(() => {
    const session = resolveAuthFromUrl();
    if (session) setClientAuth(session);
    setAuthChecked(true);
  }, [resolveAuthFromUrl]);

  useEffect(() => {
    loadMasterData();
  }, [loadMasterData]);

  useEffect(() => {
    if (clientAuth) loadAppointments();
  }, [clientAuth, loadAppointments]);

  useEffect(() => {
    if (selectedDate && master && clientAuth && selectedSalonMaster) loadSlots();
  }, [selectedDate, master, clientAuth, selectedSalonMaster, selectedService, rescheduleId]);

  useEffect(() => {
    if (clientAuth?.firstName && !formData.name) {
      setFormData((prev) => ({ ...prev, name: clientAuth.firstName }));
    }
  }, [clientAuth, formData.name]);

  useEffect(() => {
    if (!clientAuth || !masterId) return;
    axios.post('/api/client/identify', {
      masterId,
      channel: clientAuth.channel,
      userId: clientAuth.userId,
      name: formData.name || clientAuth.firstName || undefined,
      phone: formData.phone || undefined
    }).catch(() => {});
  }, [clientAuth, masterId]);

  useEffect(() => {
    if (!rescheduleId || !clientAuth || !master || teamMasters.length === 0) return;
    let cancelled = false;
    (async () => {
      setRescheduleLoading(true);
      try {
        const res = await axios.get(`/api/client/appointment/${rescheduleId}`, {
          params: { channel: clientAuth.channel, userId: clientAuth.userId }
        });
        if (cancelled) return;
        const apt = res.data;
        const teamMaster = teamMasters.find((m) => m.id === apt.salon_master_id) || teamMasters[0] || null;
        const groupServices = priceGroups.find((g) => g.master.id === apt.salon_master_id)?.services || priceList;
        const service = groupServices.find((item) => item.name === apt.service_name) || {
          id: apt.id,
          name: apt.service_name,
          price: apt.service_price,
          duration_minutes: apt.duration_minutes
        };
        setSelectedSalonMaster(teamMaster);
        setSelectedService(service);
        setSelectedDate(new Date(apt.appointment_time));
        setSelectedSlot(null);
        setActiveTab('booking');
        setStep('pick');
      } catch (err) {
        alert(err.response?.data?.error || 'Не удалось загрузить запись для переноса');
        setRescheduleId(null);
      } finally {
        if (!cancelled) setRescheduleLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [rescheduleId, clientAuth, master, teamMasters, priceGroups, priceList]);

  const handleAuthenticated = useCallback((session) => {
    setClientSession(masterId, session);
    setClientAuth(session);
    if (session.firstName) setFormData((prev) => ({ ...prev, name: prev.name || session.firstName }));
  }, [masterId]);

  const loadSlots = async () => {
    try {
      const dateStr = selectedDate.toISOString().split('T')[0];
      if (!selectedSalonMaster?.id) return;
      const params = new URLSearchParams({
        date: dateStr,
        salonMasterId: selectedSalonMaster.id,
        durationMinutes: String(selectedService?.duration_minutes || 60)
      });
      if (rescheduleId) params.set('excludeAppointmentId', rescheduleId);
      const res = await axios.get(`/api/client/${masterId}/slots?${params.toString()}`);
      setAvailableSlots(res.data);
      setSelectedSlot(null);
    } catch (err) {
      console.error(err);
    }
  };

  const servicesForMaster = useMemo(() => {
    if (!selectedSalonMaster) return priceList;
    const group = priceGroups.find((g) => g.master.id === selectedSalonMaster.id);
    return group?.services?.length ? group.services : priceList;
  }, [priceGroups, selectedSalonMaster, priceList]);

  const mapUrl = useMemo(() => buildMapUrl(master), [master]);
  const mediaItems = useMemo(() => portfolio.filter((p) => p.image_url || p.video_url), [portfolio]);
  const title = master?.salon_name || master?.name || 'Мастер';

  const pickSalonMaster = (m) => {
    setSelectedSalonMaster(m);
    setSelectedService(null);
    setSelectedSlot(null);
    setStep('pick');
  };

  const pickService = (item, masterRow = selectedSalonMaster) => {
    if (masterRow) setSelectedSalonMaster(masterRow);
    setSelectedService(item);
    setSelectedSlot(null);
    setStep('pick');
    setActiveTab('booking');
    setTimeout(() => document.getElementById('booking-card')?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 50);
  };

  const handleBooking = async (e) => {
    e.preventDefault();
    if (!selectedSlot || !selectedService || !formData.name.trim() || !clientAuth) return;
    setBooking(true);
    const wasRescheduling = !!rescheduleId;
    try {
      const payload = {
        masterId,
        salonMasterId: selectedSalonMaster?.id,
        channel: clientAuth.channel,
        name: formData.name.trim(),
        phone: formData.phone.trim(),
        appointmentTime: selectedSlot,
        serviceName: selectedService.name,
        servicePrice: selectedService.price,
        duration: selectedService.duration_minutes
      };
      if (clientAuth.channel === 'telegram') payload.telegramUserId = clientAuth.userId;
      else payload.maxUserId = clientAuth.userId;

      if (rescheduleId) await axios.put(`/api/client/appointment/${rescheduleId}/reschedule`, payload);
      else await axios.post('/api/client/book', payload);

      setStep('done');
      if (wasRescheduling) setRescheduleId(null);
      await loadAppointments();
    } catch (err) {
      alert(err.response?.data?.error || 'Ошибка записи');
    } finally {
      setBooking(false);
    }
  };

  const cancelAppointment = async (appointmentId) => {
    if (!confirm('Отменить запись?')) return;
    try {
      const payload = { channel: clientAuth.channel, userId: clientAuth.userId };
      if (clientAuth.channel === 'telegram') payload.telegramUserId = clientAuth.userId;
      else payload.maxUserId = clientAuth.userId;
      await axios.post(`/api/client/cancel/${appointmentId}`, payload);
      await loadAppointments();
    } catch (err) {
      alert(err.response?.data?.error || 'Не удалось отменить запись');
    }
  };

  const rescheduleAppointment = (apt) => {
    setRescheduleId(apt.id);
    setActiveTab('booking');
    setStep('pick');
  };

  const handleSwitchAccount = () => {
    clearClientSession(masterId);
    setClientAuth(null);
    setStep('pick');
    setSelectedSlot(null);
  };

  if (loading) {
    return <div className="min-h-screen bg-slate-100 flex items-center justify-center"><PageLoader /></div>;
  }

  if (!master) {
    return (
      <div className="min-h-screen bg-slate-100 flex items-center justify-center p-6">
        <div className="card-light max-w-md text-center p-10">
          <h2 className="text-xl font-bold">Мастер не найден</h2>
          <p className="text-ink-secondary mt-2 text-sm">Проверьте ссылку</p>
        </div>
      </div>
    );
  }

  if (authChecked && !clientAuth) {
    return (
      <div className="min-h-screen bg-slate-100 flex flex-col">
        <header className="bg-white border-b border-slate-200 px-4 py-3">
          <div className="max-w-lg mx-auto flex items-center justify-center"><Logo /></div>
        </header>
        <main className="flex-1 flex items-center justify-center p-4">
          <ClientAuthGate
            master={master}
            masterIdEncoded={masterId}
            telegramBotUsername={bookingConfig?.telegramBotUsername}
            telegramBotDeepLink={bookingConfig?.telegramBotDeepLink}
            maxBotDeepLink={bookingConfig?.maxBotDeepLink}
            onAuthenticated={handleAuthenticated}
          />
        </main>
      </div>
    );
  }

  if (!clientAuth) {
    return <div className="min-h-screen bg-slate-100 flex items-center justify-center"><PageLoader /></div>;
  }

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col">
      <header className="sticky top-0 z-30 border-b border-slate-200/80 bg-white/90 px-4 py-3 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-3">
          <Logo />
          <div className="flex items-center gap-2">
            <Badge tone={clientAuth.channel === 'telegram' ? 'telegram' : 'max'} />
            <button type="button" onClick={handleSwitchAccount} className="text-xs font-medium text-ink-muted hover:text-primary">
              Сменить
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto w-full max-w-6xl flex-1 p-4 pb-24 lg:p-6">
        {activeTab === 'home' && (
          <div className="space-y-6">
            <section className="overflow-hidden rounded-[2rem] bg-gradient-to-br from-slate-950 via-slate-900 to-primary p-6 text-white shadow-elevated lg:p-10">
              <div className="grid gap-8 lg:grid-cols-[1.4fr_0.8fr] lg:items-center">
                <div>
                  <div className="mb-6 flex items-center gap-4">
                    <div className="h-20 w-20 overflow-hidden rounded-3xl border border-white/20 bg-white/10">
                      {master.logo_url ? (
                        <img src={mediaUrl(master.logo_url)} alt="" className="h-full w-full object-cover" />
                      ) : (
                        <div className="flex h-full w-full items-center justify-center text-3xl font-bold">{title[0]}</div>
                      )}
                    </div>
                    <div>
                      <p className="text-sm font-semibold uppercase tracking-wide text-white/60">Онлайн-запись</p>
                      <h1 className="mt-1 font-display text-3xl font-bold lg:text-5xl">{title}</h1>
                      {master.salon_name && <p className="mt-1 text-white/70">{master.name}</p>}
                    </div>
                  </div>
                  {master.description && <p className="max-w-2xl text-base leading-relaxed text-white/80 lg:text-lg">{master.description}</p>}
                  <div className="mt-6 flex flex-wrap gap-3">
                    <Button size="lg" onClick={() => setActiveTab('booking')} className="bg-white !text-primary hover:bg-white/90">
                      Записаться
                    </Button>
                    <Button size="lg" variant="secondary" onClick={() => setActiveTab('appointments')} className="border-white/20 bg-white/10 !text-white hover:bg-white/20">
                      Мои записи
                    </Button>
                    {master.phone && (
                      <a href={`tel:${master.phone}`}>
                        <Button size="lg" variant="ghost" light><Phone className="h-4 w-4" />Позвонить</Button>
                      </a>
                    )}
                  </div>
                </div>
                <div className="rounded-3xl border border-white/10 bg-white/10 p-5 backdrop-blur">
                  {reviewSummary.count > 0 ? (
                    <div className="flex items-center gap-3">
                      <Star className="h-8 w-8 fill-amber-400 text-amber-400" />
                      <div>
                        <p className="text-2xl font-bold">{reviewSummary.average}</p>
                        <p className="text-sm text-white/70">{reviewSummary.count} отзывов</p>
                      </div>
                    </div>
                  ) : (
                    <p className="text-sm text-white/70">Здесь появятся отзывы клиентов после визитов</p>
                  )}
                  {master.address && (
                    <p className="mt-5 flex items-start gap-2 text-sm text-white/80">
                      <MapPin className="mt-0.5 h-4 w-4 shrink-0" />{master.address}
                    </p>
                  )}
                </div>
              </div>
            </section>

            {mediaItems.length > 0 && (
              <section className="card-light">
                <div className="mb-4 flex items-center justify-between gap-3">
                  <div>
                    <h2 className="text-xl font-bold text-ink">Фото и видео</h2>
                    <p className="text-sm text-ink-muted">Листайте работы, процесс и атмосферу</p>
                  </div>
                  <ImageIcon className="h-5 w-5 text-primary" />
                </div>
                <div className="flex gap-3 overflow-x-auto pb-2">
                  {mediaItems.map((item, idx) => (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => setMediaIndex(idx)}
                      className="relative h-56 w-40 shrink-0 overflow-hidden rounded-3xl bg-slate-100 text-left shadow-sm transition hover:scale-[1.01] sm:w-56"
                    >
                      <MediaPreview item={item} />
                      {item.media_type !== 'image' && (
                        <span className="absolute left-3 top-3 rounded-full bg-black/60 p-2 text-white"><Play className="h-4 w-4" /></span>
                      )}
                      {item.title && (
                        <span className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/70 to-transparent p-3 text-sm font-semibold text-white">
                          {item.title}
                        </span>
                      )}
                    </button>
                  ))}
                </div>
              </section>
            )}

            <section className="card-light">
              <div className="mb-5">
                <h2 className="text-xl font-bold text-ink">Услуги и цены</h2>
                <p className="text-sm text-ink-muted">Выберите услугу и сразу переходите к записи</p>
              </div>
              <div className="space-y-6">
                {priceGroups.map((group) => (
                  <div key={group.master.id}>
                    {priceGroups.length > 1 && (
                      <div className="mb-3 flex items-center gap-3">
                        <div className="h-11 w-11 overflow-hidden rounded-2xl bg-primary/10">
                          {group.master.photo_url ? <img src={mediaUrl(group.master.photo_url)} alt="" className="h-full w-full object-cover" /> : <div className="flex h-full w-full items-center justify-center font-bold text-primary">{group.master.name?.[0]}</div>}
                        </div>
                        <div>
                          <p className="font-semibold text-ink">{group.master.name}</p>
                          {group.master.specialty && <p className="text-xs text-ink-muted">{group.master.specialty}</p>}
                        </div>
                      </div>
                    )}
                    <div className="grid gap-3 md:grid-cols-2">
                      {group.services.map((item) => (
                        <button
                          key={item.id}
                          type="button"
                          onClick={() => pickService(item, group.master)}
                          className="rounded-2xl border border-slate-100 bg-slate-50 p-4 text-left transition hover:border-primary/30 hover:bg-primary/5"
                        >
                          <div className="flex items-start justify-between gap-3">
                            <div>
                              <p className="font-semibold text-ink">{item.name}</p>
                              <p className="mt-1 flex items-center gap-1 text-xs text-ink-muted"><Clock className="h-3.5 w-3.5" />{item.duration_minutes} мин</p>
                            </div>
                            <p className="font-bold text-primary">{formatPrice(item.price)}</p>
                          </div>
                          <span className="mt-3 inline-flex text-sm font-semibold text-primary">Выбрать</span>
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {mapUrl && (
              <section className="card-light overflow-hidden">
                <div className="mb-4 flex items-center gap-2">
                  <MapPin className="h-5 w-5 text-primary" />
                  <div>
                    <h2 className="text-xl font-bold text-ink">Как добраться</h2>
                    {master.address && <p className="text-sm text-ink-muted">{master.address}</p>}
                  </div>
                </div>
                <iframe title="Карта" src={mapUrl} className="h-72 w-full rounded-3xl border-0 bg-slate-100" loading="lazy" />
              </section>
            )}
          </div>
        )}

        {activeTab === 'appointments' && (
          <section className="card-light">
            <h2 className="text-xl font-bold text-ink">Мои записи</h2>
            <p className="mt-1 text-sm text-ink-muted">Здесь можно перенести, отменить или написать мастеру</p>
            <div className="mt-5 space-y-3">
              {appointmentsLoading ? (
                <div className="py-10"><PageLoader /></div>
              ) : appointments.length === 0 ? (
                <div className="rounded-3xl bg-slate-50 p-8 text-center">
                  <p className="font-semibold text-ink">Записей пока нет</p>
                  <Button className="mt-4" onClick={() => setActiveTab('booking')}>Записаться</Button>
                </div>
              ) : (
                appointments.map((apt) => (
                  <div key={apt.id} className="rounded-3xl border border-slate-100 bg-white p-4 shadow-sm">
                    <p className="font-semibold text-ink">{apt.service_name}</p>
                    <p className="mt-1 text-sm text-ink-secondary">{formatDateTime(apt.appointment_time)}</p>
                    {apt.address && <p className="mt-1 text-sm text-ink-muted">{apt.address}</p>}
                    <div className="mt-4 flex flex-wrap gap-2">
                      <Button size="sm" onClick={() => rescheduleAppointment(apt)}>Перенести</Button>
                      <Button size="sm" variant="secondary" onClick={() => { setActiveTab('chat'); }}>Написать мастеру</Button>
                      <Button size="sm" variant="danger" onClick={() => cancelAppointment(apt.id)}>Отменить</Button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </section>
        )}

        {activeTab === 'chat' && (
          <section className="card-light">
            <ClientChatPanel masterId={masterId} clientAuth={clientAuth} formData={formData} />
          </section>
        )}

        {activeTab === 'reviews' && (
          <section className="card-light">
            <ClientReviewsPanel reviews={reviews} reviewSummary={reviewSummary} masterId={masterId} clientAuth={clientAuth} formData={formData} onSubmitted={loadMasterData} />
          </section>
        )}

        {activeTab === 'booking' && (
          <section id="booking-card" className="card-light">
            {step === 'done' ? (
              <div className="py-12 text-center">
                <div className="mx-auto mb-6 flex h-20 w-20 items-center justify-center rounded-full bg-success-soft text-4xl">✓</div>
                <h2 className="text-2xl font-bold text-ink">{rescheduleId ? 'Запись перенесена!' : 'Вы записаны!'}</h2>
                <p className="mt-2 text-ink-secondary">{selectedService?.name} · {selectedSlot && new Date(selectedSlot).toLocaleString('ru-RU')}</p>
                <p className="mt-4 flex items-center justify-center gap-1 text-sm text-ink-muted">Напоминание в <MessengerLabel channel={clientAuth.channel} size="xs" /></p>
                <Button className="mt-8" variant="secondary" onClick={() => { setRescheduleId(null); setStep('pick'); setSelectedSlot(null); loadAppointments(); }}>Новая запись</Button>
              </div>
            ) : (
              <>
                <h2 className="text-xl font-bold text-ink">{rescheduleId ? 'Перенести запись' : 'Записаться'}</h2>
                {rescheduleId && (
                  <div className="mt-4 rounded-2xl border border-amber-100 bg-amber-50 px-4 py-3 text-sm text-amber-800">
                    {rescheduleLoading ? 'Загружаем вашу запись...' : 'Выберите новое удобное время и подтвердите перенос записи.'}
                  </div>
                )}
                {teamMasters.length > 1 && (
                  <div className="mt-5">
                    <p className="mb-2 text-sm font-semibold text-ink">Мастер</p>
                    <div className="flex gap-2 overflow-x-auto pb-1">
                      {teamMasters.map((m) => (
                        <button key={m.id} type="button" onClick={() => pickSalonMaster(m)} className={`flex shrink-0 items-center gap-2 rounded-2xl border px-3 py-2 transition ${selectedSalonMaster?.id === m.id ? 'border-primary bg-primary/10' : 'border-slate-200 hover:border-primary/40'}`}>
                          <div className="h-10 w-10 overflow-hidden rounded-xl bg-primary/10">
                            {m.photo_url ? <img src={mediaUrl(m.photo_url)} alt="" className="h-full w-full object-cover" /> : <div className="flex h-full w-full items-center justify-center text-sm font-bold text-primary">{m.name?.[0]}</div>}
                          </div>
                          <span className="text-sm font-semibold text-ink">{m.name}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}
                <div className="mt-5 grid gap-3 md:grid-cols-2">
                  {servicesForMaster.map((item) => (
                    <button key={item.id} type="button" onClick={() => pickService(item)} className={`rounded-2xl border p-4 text-left transition ${selectedService?.id === item.id ? 'border-primary bg-primary/10' : 'border-slate-100 bg-slate-50 hover:border-primary/30'}`}>
                      <p className="font-semibold text-ink">{item.name}</p>
                      <p className="mt-1 text-xs text-ink-muted">{item.duration_minutes} мин · {formatPrice(item.price)}</p>
                    </button>
                  ))}
                </div>
                <div className="mt-6 grid gap-6 lg:grid-cols-2">
                  <div>
                    <p className="mb-2 text-sm font-semibold text-ink">Дата</p>
                    <Calendar onChange={setSelectedDate} value={selectedDate} minDate={new Date()} locale="ru-RU" />
                  </div>
                  <div>
                    <p className="mb-2 text-sm font-semibold text-ink">Время</p>
                    {availableSlots.length === 0 ? (
                      <p className="rounded-2xl bg-slate-50 py-8 text-center text-sm text-ink-muted">Нет свободных слотов</p>
                    ) : (
                      <div className="grid max-h-72 grid-cols-2 gap-2 overflow-y-auto pr-1">
                        {availableSlots.map((slot) => {
                          const label = new Date(slot).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
                          return (
                            <button key={slot} type="button" onClick={() => { setSelectedSlot(slot); setStep('form'); }} className={`rounded-2xl py-3 text-sm font-semibold transition ${selectedSlot === slot ? 'bg-primary text-white shadow-md shadow-primary/30' : 'bg-slate-100 text-ink hover:bg-slate-200'}`}>
                              {label}
                            </button>
                          );
                        })}
                      </div>
                    )}
                  </div>
                </div>
                {step === 'form' && selectedSlot && (
                  <form onSubmit={handleBooking} className="mt-6 space-y-4 border-t border-slate-100 pt-6">
                    <div className="grid gap-4 sm:grid-cols-2">
                      <Input label="Ваше имя" required value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} />
                      <Input label="Телефон" type="tel" value={formData.phone} onChange={(e) => setFormData({ ...formData, phone: e.target.value })} />
                    </div>
                    <Button type="submit" className="w-full !py-4 text-base shadow-glow" size="lg" loading={booking}>
                      {rescheduleId ? 'Перенести запись' : 'Записаться'}
                    </Button>
                  </form>
                )}
              </>
            )}
          </section>
        )}
      </main>

      <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-slate-200 bg-white/95 backdrop-blur lg:hidden">
        <div className="flex justify-around py-2">
          {CLIENT_TABS.map(({ id, label, Icon }) => (
            <button key={id} type="button" onClick={() => setActiveTab(id)} className={`flex flex-col items-center gap-1 px-2 py-1 text-[11px] font-semibold ${activeTab === id ? 'text-primary' : 'text-ink-muted'}`}>
              <Icon className="h-5 w-5" />
              {label}
            </button>
          ))}
        </div>
      </nav>

      <div className="hidden border-t border-slate-200 bg-white lg:block">
        <div className="mx-auto flex max-w-6xl justify-center gap-2 p-3">
          {CLIENT_TABS.map(({ id, label, Icon }) => (
            <button key={id} type="button" onClick={() => setActiveTab(id)} className={`inline-flex items-center gap-2 rounded-2xl px-4 py-2 text-sm font-semibold ${activeTab === id ? 'bg-primary text-white' : 'text-ink-muted hover:bg-slate-100'}`}>
              <Icon className="h-4 w-4" />
              {label}
            </button>
          ))}
        </div>
      </div>

      <Modal open={mediaIndex != null} onClose={() => setMediaIndex(null)} title={mediaIndex != null ? mediaItems[mediaIndex]?.title || 'Медиа' : 'Медиа'} size="lg">
        {mediaIndex != null && mediaItems[mediaIndex] && (
          <div>
            <div className="overflow-hidden rounded-3xl bg-slate-950">
              {mediaItems[mediaIndex].media_type === 'video' ? (
                <video src={mediaUrl(mediaItems[mediaIndex].video_url)} controls autoPlay className="max-h-[65vh] w-full object-contain" />
              ) : mediaItems[mediaIndex].media_type === 'external_video' ? (
                <div className="p-6 text-center text-white">
                  <Play className="mx-auto h-12 w-12" />
                  <a href={mediaItems[mediaIndex].video_url} target="_blank" rel="noreferrer" className="mt-4 block break-all text-primary-100 underline">
                    Открыть видео
                  </a>
                </div>
              ) : (
                <img src={mediaUrl(mediaItems[mediaIndex].image_url)} alt="" className="max-h-[65vh] w-full object-contain" />
              )}
            </div>
            <div className="mt-4 flex justify-between gap-3">
              <Button variant="secondary" onClick={() => setMediaIndex((idx) => (idx > 0 ? idx - 1 : mediaItems.length - 1))}>Назад</Button>
              <Button variant="secondary" onClick={() => setMediaIndex((idx) => (idx < mediaItems.length - 1 ? idx + 1 : 0))}>Вперёд</Button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
