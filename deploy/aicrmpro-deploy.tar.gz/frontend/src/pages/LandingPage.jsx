import { useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { scrollToSection } from '../lib/scrollToSection';
import {
  Building2,
  Calendar,
  CalendarClock,
  Check,
  ChevronRight,
  Ellipsis,
  Gift,
  Images,
  Link2,
  MessageCircle,
  Rocket,
  Users
} from 'lucide-react';
import { LANDING_MASTERS } from '../config/landingMasters';
import Button from '../components/ui/Button';
import IconBox from '../components/ui/IconBox';
import HeroMockups from '../components/landing/HeroMockups';
import ChannelLinks from '../components/landing/ChannelLinks';
import PricingSection from '../components/landing/PricingSection';
import FeaturesSection from '../components/landing/FeaturesSection';
import SiteFooter from '../components/layout/SiteFooter';
import SiteHeader, { SITE_HEADER_OFFSET } from '../components/layout/SiteHeader';

const iconStroke = { strokeWidth: 1.75 };

const HERO_FEATURES = [
  {
    Icon: CalendarClock,
    title: 'Онлайн-запись 24/7',
    desc: 'Клиенты записываются в любое время'
  },
  {
    Icon: Users,
    title: 'Больше клиентов',
    desc: 'Удобный сервис = больше записей и повторных визитов'
  }
];

const STEPS = [
  { Icon: Building2, text: 'Мастер создаёт свою компанию. Добавляет фото, описание, услуги, прайс и портфолио.' },
  { Icon: Link2, text: 'Получает одну ссылку для Telegram, MAX, ВКонтакте и Instagram* — и делится ею с клиентами.' },
  { Icon: Calendar, text: 'Клиент выбирает дату и время. И записывается на услугу или вызывает мастера на дом.' },
  { Icon: Images, text: 'Клиент изучает. Портфолио, прайс-листы, услуги и отзывы о мастере.' },
  { Icon: MessageCircle, text: 'Связь с мастером. Клиент может написать в чат, задать вопросы и уточнить детали.' }
];

const BENEFITS = [
  'Удобно для мастеров',
  'Просто для клиентов',
  'Больше записей и прибыли',
  'Автоматизация и аналитика',
  'Работает в Telegram, MAX, ВК и Instagram*'
];

export default function LandingPage() {
  const location = useLocation();

  useEffect(() => {
    const fromHash = location.hash?.replace('#', '');
    const fromState = location.state?.scrollTo;
    const sectionId = fromHash || fromState;
    if (!sectionId) return;

    const timer = window.setTimeout(() => scrollToSection(sectionId), 50);
    return () => window.clearTimeout(timer);
  }, [location.pathname, location.hash, location.state]);

  return (
    <div className="min-h-screen bg-[#f6f4ff] text-ink">
      <SiteHeader />

      <main className={SITE_HEADER_OFFSET}>
        <section className="relative px-4 pt-6 pb-10 sm:pt-8 sm:pb-12 lg:px-8 lg:pt-12 lg:pb-24 overflow-x-hidden">
          <div className="pointer-events-none absolute inset-0 bg-gradient-to-br from-[#ede9fe] via-[#faf8ff] to-[#e0e7ff]" />
          <div className="pointer-events-none absolute -right-32 top-20 h-96 w-96 rounded-full bg-violet-200/40 blur-3xl" />
          <div className="pointer-events-none absolute -left-20 bottom-0 h-72 w-72 rounded-full bg-blue-200/30 blur-3xl" />

          <div className="relative mx-auto max-w-7xl">
            <div className="grid items-start gap-6 sm:gap-8 lg:grid-cols-2 lg:gap-10 xl:gap-14">
              <div className="pt-0 sm:pt-2">
                <span className="inline-flex items-center gap-2 rounded-full border border-violet-200/80 bg-white px-4 py-1.5 text-sm font-medium text-violet-700 shadow-sm">
                  <span className="h-1.5 w-1.5 rounded-full bg-primary animate-pulse" />
                  CRM для мастеров услуг
                </span>

                <h1 className="mt-5 text-[2rem] font-black leading-[1.12] tracking-tight text-slate-900 sm:text-5xl lg:text-[3.15rem]">
                  CRM для мастеров —{' '}
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-violet-600 via-indigo-500 to-blue-500">
                    всё в одном кабинете
                  </span>
                </h1>

                <p className="mt-3 text-lg font-semibold text-violet-700 sm:text-xl">
                  Мы заботимся о вашем времени.
                </p>

                <p className="mt-3 max-w-lg text-base text-slate-600 leading-relaxed sm:text-lg">
                  Онлайн-запись, база клиентов, расписание, прайс, портфолио и рассылки в MAX и Telegram — без лишних
                  сервисов.
                </p>

                <div className="mt-5 space-y-2.5 sm:mt-7 sm:space-y-3">
                  {HERO_FEATURES.map(({ Icon, title, desc }) => (
                    <div
                      key={title}
                      className="flex gap-4 rounded-2xl border border-white bg-white/95 p-4 shadow-sm shadow-violet-100/40"
                    >
                      <IconBox size="md" variant="soft">
                        <Icon {...iconStroke} />
                      </IconBox>
                      <div>
                        <p className="font-bold text-slate-900">{title}</p>
                        <p className="mt-0.5 text-sm text-slate-500">{desc}</p>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-6 flex flex-wrap gap-3 sm:mt-8">
                  <Link to="/register">
                    <Button size="lg" className="min-w-[200px] shadow-lg shadow-primary/25">
                      Начать бесплатно
                    </Button>
                  </Link>
                  <Link to="/login">
                    <Button variant="secondary" size="lg">
                      Войти в кабинет
                    </Button>
                  </Link>
                </div>

              </div>

              <div className="w-full sm:pt-4 lg:pt-8 lg:pl-4">
                <HeroMockups />
              </div>
            </div>
          </div>
        </section>

        <FeaturesSection />

        <section className="bg-[#f6f4ff] px-4 py-16 lg:px-8 lg:py-24">
          <div className="mx-auto max-w-7xl">
            <h2 className="text-center text-3xl font-black text-slate-900 sm:text-4xl">Как это работает?</h2>
            <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-5">
              {STEPS.map(({ Icon, text }, i) => (
                <div key={text} className="relative flex flex-col">
                  <div className="flex h-full flex-col rounded-2xl border border-slate-100 bg-gradient-to-b from-slate-50 to-white p-5 shadow-sm">
                    <IconBox size="lg" variant="gradient" className="mb-4">
                      <Icon {...iconStroke} />
                    </IconBox>
                    <p className="text-sm leading-relaxed text-slate-600">{text}</p>
                  </div>
                  {i < STEPS.length - 1 && (
                    <ChevronRight
                      className="absolute -right-2 top-1/2 z-10 hidden h-6 w-6 -translate-y-1/2 text-violet-300 lg:block"
                      strokeWidth={2}
                      aria-hidden
                    />
                  )}
                </div>
              ))}
            </div>
            <ChannelLinks
              variant="strip"
              className="mt-14 pt-10 border-t border-slate-100"
              subtitle="Одна ссылка на запись — клиент откроет её в любом мессенджере или соцсети"
            />
          </div>
        </section>

        <PricingSection />

        <section className="mx-4 mb-16 lg:mx-8">
          <div className="mx-auto max-w-7xl rounded-[2rem] bg-[#0f172a] px-6 py-12 text-white lg:px-14 lg:py-16">
            <div className="grid gap-12 lg:grid-cols-2 lg:items-center">
              <div>
                <h2 className="text-3xl font-black sm:text-4xl">Для любых мастеров</h2>
                <div className="mt-8 flex flex-wrap gap-4 sm:gap-5">
                  {LANDING_MASTERS.map(({ id, label, image, ringClass }) => (
                    <div key={id} className="flex w-[88px] flex-col items-center sm:w-[96px]">
                      <div
                        className={`relative h-[72px] w-[72px] overflow-hidden rounded-full ring-4 ring-white/15 sm:h-[76px] sm:w-[76px] ${ringClass}`}
                      >
                        <img
                          src={image}
                          alt={label}
                          className="h-full w-full object-cover"
                          loading="lazy"
                          width={76}
                          height={76}
                        />
                      </div>
                      <p className="mt-2 text-center text-[10px] leading-tight text-slate-300 sm:text-[11px]">{label}</p>
                    </div>
                  ))}
                  <div className="flex w-[88px] flex-col items-center sm:w-[96px]">
                    <div className="flex h-[72px] w-[72px] items-center justify-center rounded-full bg-slate-700 ring-4 ring-white/10 sm:h-[76px] sm:w-[76px]">
                      <Ellipsis className="h-8 w-8 text-slate-300" strokeWidth={1.75} />
                    </div>
                    <p className="mt-2 text-center text-[10px] text-slate-300 sm:text-[11px]">И любые другие</p>
                  </div>
                </div>
              </div>
              <ul className="space-y-4">
                {BENEFITS.map((b) => (
                  <li key={b} className="flex items-center gap-3 text-base sm:text-lg">
                    <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-blue-500 text-white">
                      <Check className="h-4 w-4" strokeWidth={2.5} />
                    </span>
                    {b}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </section>

        <section className="px-4 pb-16 lg:px-8">
          <div className="mx-auto max-w-7xl overflow-hidden rounded-[2rem] bg-gradient-to-r from-violet-600 via-indigo-600 to-blue-500 px-6 py-10 shadow-2xl shadow-violet-300/40 lg:px-12 lg:py-14">
            <div className="flex flex-col items-center gap-8 lg:flex-row lg:justify-between">
              <div className="flex items-center gap-5">
                <IconBox size="lg" variant="white" className="!h-20 !w-20 !rounded-3xl [&_svg]:!h-9 [&_svg]:!w-9">
                  <Rocket strokeWidth={1.75} />
                </IconBox>
                <div className="text-white">
                  <p className="text-xl font-black leading-tight sm:text-2xl lg:text-[1.65rem]">
                    MasterClient45 — ваш личный ассистент для роста бизнеса!
                  </p>
                  <p className="mt-2 text-sm text-violet-100 sm:text-base">
                    Больше записей. Меньше рутины. Больше прибыли.
                  </p>
                </div>
              </div>
              <Link
                to="/register"
                className="flex shrink-0 items-center gap-3 rounded-2xl bg-white px-5 py-4 font-bold text-slate-900 shadow-xl transition hover:bg-violet-50 sm:px-6"
              >
                <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-violet-100 text-primary">
                  <Gift className="h-5 w-5" strokeWidth={1.75} />
                </span>
                <span className="text-sm sm:text-base">Создать кабинет — бесплатно</span>
              </Link>
            </div>
          </div>
        </section>

      </main>

      <SiteFooter />
    </div>
  );
}
