import { useState, useEffect, useContext, useMemo, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { AuthContext } from '../App';
import { useToast } from '../context/ToastContext';
import DashboardLayout, { StatCard, MiniChart } from '../components/layout/DashboardLayout';
import Card, { CardHeader } from '../components/ui/Card';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';
import Textarea from '../components/ui/Textarea';
import Modal from '../components/ui/Modal';
import Badge from '../components/ui/Badge';
import MaxLogo from '../components/brand/MaxLogo';
import { IconTelegram } from '../components/brand/SocialBrandIcons';
import EmptyState from '../components/ui/EmptyState';
import { PageLoader } from '../components/ui/Spinner';
import { Link2, Copy, ExternalLink } from 'lucide-react';
import { DAYS, STATUS_LABELS, formatDate, formatDateTime, formatPrice } from '../lib/format';
import { mediaUrl } from '../lib/media';
import { copyToClipboard } from '../lib/clipboard';
import TeamMasterSelect from '../components/dashboard/TeamMasterSelect';
import SalonMastersSection from '../components/dashboard/SalonMastersSection';
import ClientDetailModal from '../components/dashboard/ClientDetailModal';
import AnalyticsSection from '../components/dashboard/AnalyticsSection';
import ReviewsSection from '../components/dashboard/ReviewsSection';
import ChatInboxSection from '../components/dashboard/ChatInboxSection';
import RepeatInvitesSection from '../components/dashboard/RepeatInvitesSection';
import NotifySettingsCard from '../components/dashboard/NotifySettingsCard';

function buildScheduleDraft(apiSchedule) {
  return Array.from({ length: 7 }, (_, day) => {
    const row = apiSchedule.find((s) => s.day_of_week === day);
    return row
      ? { ...row }
      : { day_of_week: day, start_time: '09:00', end_time: '18:00', is_day_off: day === 0 };
  });
}

export default function MasterDashboard() {
  const navigate = useNavigate();
  const { user, logout, api } = useContext(AuthContext);
  const { toast } = useToast();

  const [loading, setLoading] = useState(true);
  const [activeSection, setActiveSection] = useState('overview');
  const [appointments, setAppointments] = useState([]);
  const [clients, setClients] = useState([]);
  const [profile, setProfile] = useState(null);
  const [scheduleDraft, setScheduleDraft] = useState(() => buildScheduleDraft([]));
  const [exceptions, setExceptions] = useState([]);
  const [priceList, setPriceList] = useState([]);
  const [portfolio, setPortfolio] = useState([]);
  const [links, setLinks] = useState(null);
  const [profileForm, setProfileForm] = useState({});
  const [savingSchedule, setSavingSchedule] = useState(false);
  const [savingProfile, setSavingProfile] = useState(false);

  const [showPriceModal, setShowPriceModal] = useState(false);
  const [priceForm, setPriceForm] = useState({ id: null, name: '', price: '', duration_minutes: 60, is_active: true });
  const [priceImage, setPriceImage] = useState(null);

  const [showExceptionModal, setShowExceptionModal] = useState(false);
  const [exceptionForm, setExceptionForm] = useState({ exception_date: '', is_working: false, start_time: '09:00', end_time: '18:00' });

  const [showManualBook, setShowManualBook] = useState(false);
  const [manualBookForm, setManualBookForm] = useState({ clientName: '', clientPhone: '', serviceName: '', servicePrice: '', appointmentTime: '', duration: 60 });

  const [showBroadcast, setShowBroadcast] = useState(false);
  const [broadcastMessage, setBroadcastMessage] = useState('');

  const [showMessageModal, setShowMessageModal] = useState(false);
  const [messageTarget, setMessageTarget] = useState(null);
  const [clientMessage, setClientMessage] = useState('');

  const [portfolioTitle, setPortfolioTitle] = useState('');
  const [portfolioFile, setPortfolioFile] = useState(null);
  const [portfolioVideoUrl, setPortfolioVideoUrl] = useState('');
  const [portfolioMediaType, setPortfolioMediaType] = useState('image');
  const [uploadingPortfolio, setUploadingPortfolio] = useState(false);
  const [salonMasters, setSalonMasters] = useState([]);
  const [selectedSalonMasterId, setSelectedSalonMasterId] = useState(null);
  const [selectedClientId, setSelectedClientId] = useState(null);
  const [clientDeleteTarget, setClientDeleteTarget] = useState(null);
  const [deletingClient, setDeletingClient] = useState(false);
  const [messageTargetClient, setMessageTargetClient] = useState(null);
  const [navBadges, setNavBadges] = useState({ chatUnread: 0, reviewsPending: 0 });

  const refreshNavBadges = useCallback(async () => {
    try {
      const res = await api.get('/master/me/nav-badges');
      setNavBadges(res.data);
    } catch {
      /* ignore */
    }
  }, [api]);

  const teamParams = useCallback(
    () => (selectedSalonMasterId ? { params: { salonMasterId: selectedSalonMasterId } } : {}),
    [selectedSalonMasterId]
  );

  const loadTeamScoped = useCallback(
    async (teamId) => {
      if (!teamId) return;
      const params = { params: { salonMasterId: teamId } };
      const [scheduleRes, pricesRes, portfolioRes, exceptionsRes] = await Promise.all([
        api.get('/master/me/schedule', params),
        api.get('/master/me/prices', params),
        api.get('/master/me/portfolio', params),
        api.get('/master/me/exceptions', params)
      ]);
      setScheduleDraft(buildScheduleDraft(scheduleRes.data));
      setPriceList(pricesRes.data);
      setPortfolio(portfolioRes.data);
      setExceptions(exceptionsRes.data);
    },
    [api]
  );

  const loadData = useCallback(async () => {
    try {
      const [profileRes, appointmentsRes, clientsRes, linkRes, teamRes] = await Promise.all([
        api.get('/master/me/profile'),
        api.get('/appointments'),
        api.get('/master/me/clients'),
        api.get('/master/me/link'),
        api.get('/master/me/salon-masters')
      ]);

      setProfile(profileRes.data);
      setProfileForm(profileRes.data);
      setAppointments(appointmentsRes.data);
      setClients(clientsRes.data);
      setLinks(linkRes.data.links);

      const active = teamRes.data.filter((m) => m.is_active !== false);
      setSalonMasters(teamRes.data);
      const teamId =
        active.find((m) => m.id === selectedSalonMasterId)?.id || active[0]?.id || null;
      setSelectedSalonMasterId(teamId);
      if (teamId) await loadTeamScoped(teamId);
    } catch (err) {
      console.error(err);
      toast('Не удалось загрузить данные', 'error');
    } finally {
      setLoading(false);
    }
  }, [api, toast, loadTeamScoped, selectedSalonMasterId]);

  const handleTeamMasterChange = async (teamId) => {
    setSelectedSalonMasterId(teamId);
    try {
      await loadTeamScoped(teamId);
    } catch {
      toast('Не удалось загрузить данные мастера', 'error');
    }
  };

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }
    loadData();
    refreshNavBadges();
    const t = setInterval(refreshNavBadges, 20000);
    return () => clearInterval(t);
  }, [user, navigate, loadData, refreshNavBadges]);

  const handleDeleteClient = async () => {
    if (!clientDeleteTarget) return;
    setDeletingClient(true);
    try {
      await api.delete(`/master/me/clients/${clientDeleteTarget.id}`);
      setClients((items) => items.filter((item) => item.id !== clientDeleteTarget.id));
      if (selectedClientId === clientDeleteTarget.id) setSelectedClientId(null);
      setClientDeleteTarget(null);
      toast('Клиент удалён из базы');
    } catch (err) {
      toast(err.response?.data?.error || 'Ошибка удаления клиента', 'error');
    } finally {
      setDeletingClient(false);
    }
  };

  const stats = useMemo(() => {
    const upcoming = appointments.filter((a) => a.status === 'confirmed' && new Date(a.appointment_time) >= new Date());
    const today = upcoming.filter((a) => new Date(a.appointment_time).toDateString() === new Date().toDateString());
    const revenue = appointments
      .filter((a) => a.status !== 'cancelled' && a.service_price)
      .reduce((s, a) => s + Number(a.service_price), 0);
    const weekChart = [0, 0, 0, 0, 0, 0, 0];
    if (appointments.length > 0) {
      const byDay = [0, 0, 0, 0, 0, 0, 0];
      appointments.forEach((a) => {
        const d = new Date(a.appointment_time).getDay();
        const idx = d === 0 ? 6 : d - 1;
        byDay[idx]++;
      });
      for (let i = 0; i < 7; i++) weekChart[i] = byDay[i];
    }
    return {
      total: appointments.length,
      upcoming: upcoming.length,
      today: today.length,
      clients: clients.length,
      services: priceList.filter((p) => p.is_active !== false).length,
      revenue,
      weekChart
    };
  }, [appointments, clients, priceList]);

  const copyLink = async (url) => {
    const text = url || clientBookingUrl;
    if (!text) {
      toast('Ссылка ещё не загружена', 'error');
      return;
    }
    try {
      await copyToClipboard(text);
      toast('Ссылка скопирована');
    } catch {
      toast('Не удалось скопировать — выделите текст ссылки и скопируйте вручную (Ctrl+C)', 'error');
    }
  };

  const handleProfileUpdate = async () => {
    setSavingProfile(true);
    try {
      await api.put('/master/me/profile', profileForm);
      toast('Профиль сохранён');
      loadData();
    } catch {
      toast('Ошибка сохранения профиля', 'error');
    } finally {
      setSavingProfile(false);
    }
  };

  const handleLogoUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const fd = new FormData();
    fd.append('logo', file);
    try {
      await api.post('/master/me/logo', fd, { headers: { 'Content-Type': 'multipart/form-data' } });
      toast('Логотип обновлён');
      loadData();
    } catch {
      toast('Ошибка загрузки логотипа', 'error');
    }
  };

  const handleScheduleSaveAll = async () => {
    setSavingSchedule(true);
    try {
      await api.post('/master/me/schedule', { schedule: scheduleDraft, salonMasterId: selectedSalonMasterId });
      toast('Расписание сохранено');
      loadData();
    } catch {
      toast('Ошибка сохранения расписания', 'error');
    } finally {
      setSavingSchedule(false);
    }
  };

  const updateScheduleDay = (day, patch) => {
    setScheduleDraft((prev) =>
      prev.map((d) => (d.day_of_week === day ? { ...d, ...patch } : d))
    );
  };

  const handleExceptionSubmit = async (e) => {
    e.preventDefault();
    try {
      await api.post('/master/me/exceptions', { ...exceptionForm, salonMasterId: selectedSalonMasterId });
      toast('Исключение добавлено');
      setShowExceptionModal(false);
      setExceptionForm({ exception_date: '', is_working: false, start_time: '09:00', end_time: '18:00' });
      loadData();
    } catch {
      toast('Ошибка сохранения', 'error');
    }
  };

  const handleExceptionDelete = async (id) => {
    if (!confirm('Удалить исключение?')) return;
    try {
      await api.delete(`/master/me/exceptions/${id}`, teamParams());
      toast('Удалено');
      loadData();
    } catch {
      toast('Ошибка удаления', 'error');
    }
  };

  const openPriceModal = (item = null) => {
    if (item) {
      setPriceForm({
        id: item.id,
        name: item.name,
        price: item.price,
        duration_minutes: item.duration_minutes,
        is_active: item.is_active !== false,
        image_url: item.image_url
      });
    } else {
      setPriceForm({ id: null, name: '', price: '', duration_minutes: 60, is_active: true });
    }
    setPriceImage(null);
    setShowPriceModal(true);
  };

  const handlePriceSubmit = async (e) => {
    e.preventDefault();
    try {
      let image_url = priceForm.image_url;
      if (priceImage) {
        const fd = new FormData();
        fd.append('image', priceImage);
        const up = await api.post('/master/me/prices/upload', fd, { headers: { 'Content-Type': 'multipart/form-data' } });
        image_url = up.data.image_url;
      }
      await api.post('/master/me/prices', {
        id: priceForm.id,
        name: priceForm.name,
        price: Number(priceForm.price),
        duration_minutes: Number(priceForm.duration_minutes),
        is_active: priceForm.is_active,
        image_url,
        salonMasterId: selectedSalonMasterId
      });
      toast(priceForm.id ? 'Услуга обновлена' : 'Услуга добавлена');
      setShowPriceModal(false);
      loadData();
    } catch {
      toast('Ошибка сохранения услуги', 'error');
    }
  };

  const handlePriceDelete = async (id) => {
    if (!confirm('Удалить услугу?')) return;
    try {
      await api.delete(`/master/me/prices/${id}`, teamParams());
      toast('Услуга удалена');
      loadData();
    } catch {
      toast('Ошибка удаления', 'error');
    }
  };

  const handlePortfolioUpload = async (e) => {
    e.preventDefault();
    if (portfolioMediaType === 'external_video' && !portfolioVideoUrl.trim()) {
      toast('Добавьте ссылку на видео', 'error');
      return;
    }
    if (portfolioMediaType !== 'external_video' && !portfolioFile) {
      toast('Выберите файл', 'error');
      return;
    }
    setUploadingPortfolio(true);
    try {
      const fd = new FormData();
      if (portfolioFile) fd.append('media', portfolioFile);
      fd.append('title', portfolioTitle);
      fd.append('salonMasterId', selectedSalonMasterId || '');
      fd.append('media_type', portfolioMediaType);
      fd.append('video_url', portfolioVideoUrl);
      await api.post('/master/me/portfolio', fd, { headers: { 'Content-Type': 'multipart/form-data' } });
      toast('Медиа добавлено');
      setPortfolioFile(null);
      setPortfolioTitle('');
      setPortfolioVideoUrl('');
      loadData();
    } catch (err) {
      toast(err.response?.data?.error || 'Ошибка загрузки', 'error');
    } finally {
      setUploadingPortfolio(false);
    }
  };

  const handlePortfolioDelete = async (id) => {
    if (!confirm('Удалить фото?')) return;
    try {
      await api.delete(`/master/me/portfolio/${id}`, teamParams());
      toast('Фото удалено');
      loadData();
    } catch {
      toast('Ошибка удаления', 'error');
    }
  };

  const handleManualBook = async (e) => {
    e.preventDefault();
    try {
      await api.post('/appointments', {
        clientName: manualBookForm.clientName,
        clientPhone: manualBookForm.clientPhone,
        serviceName: manualBookForm.serviceName,
        servicePrice: manualBookForm.servicePrice ? Number(manualBookForm.servicePrice) : null,
        appointmentTime: new Date(manualBookForm.appointmentTime).toISOString(),
        duration: Number(manualBookForm.duration) || 60
      });
      toast('Запись создана');
      setShowManualBook(false);
      setManualBookForm({ clientName: '', clientPhone: '', serviceName: '', servicePrice: '', appointmentTime: '', duration: 60 });
      loadData();
    } catch (err) {
      toast(err.response?.data?.error || 'Ошибка создания записи', 'error');
    }
  };

  const handleBroadcast = async () => {
    if (!broadcastMessage.trim()) return;
    try {
      const res = await api.post('/master/me/broadcast', { message: broadcastMessage });
      toast(`Рассылка: ${res.data.recipients} получателей`);
      setShowBroadcast(false);
      setBroadcastMessage('');
    } catch {
      toast('Ошибка рассылки', 'error');
    }
  };

  const handleAppointmentStatus = async (id, status) => {
    try {
      await api.put(`/appointments/${id}`, { status });
      toast('Статус обновлён');
      loadData();
    } catch {
      toast('Ошибка обновления', 'error');
    }
  };

  const handleDeleteAppointment = async (id) => {
    if (!confirm('Удалить запись?')) return;
    try {
      await api.delete(`/appointments/${id}`);
      toast('Запись удалена');
      loadData();
    } catch {
      toast('Ошибка удаления', 'error');
    }
  };

  const sendClientMessage = async () => {
    if (!clientMessage.trim()) return;
    const target = messageTargetClient || messageTarget;
    if (!target) return;
    try {
      if (messageTargetClient) {
        await api.post(`/master/me/clients/${messageTargetClient.id}/message`, { message: clientMessage });
      } else {
        await api.post(`/appointments/${messageTarget.id}/message`, { message: clientMessage });
      }
      toast('Сообщение отправлено');
      setShowMessageModal(false);
      setClientMessage('');
      setMessageTarget(null);
      setMessageTargetClient(null);
    } catch (err) {
      toast(err.response?.data?.error || 'Не удалось отправить сообщение', 'error');
    }
  };

  const openClientMessage = (client) => {
    setMessageTargetClient(client);
    setMessageTarget(null);
    setClientMessage('');
    setShowMessageModal(true);
  };

  const clientBookingUrl = links?.client?.web || links?.max?.web;

  if (loading) return <PageLoader />;

  return (
    <DashboardLayout
      profile={profile}
      activeSection={activeSection}
      onSectionChange={setActiveSection}
      navBadges={navBadges}
      onLogout={() => {
        logout();
        navigate('/login');
      }}
    >
      {activeSection === 'overview' && (
        <div className="space-y-6">
          {clientBookingUrl && (
            <div className="relative overflow-hidden rounded-2xl border-2 border-primary/40 bg-gradient-to-br from-primary via-primary-600 to-violet-600 p-6 sm:p-8 text-white shadow-lg shadow-primary/25">
              <div className="absolute -right-8 -top-8 h-40 w-40 rounded-full bg-white/10 blur-2xl pointer-events-none" />
              <div className="relative flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
                <div className="flex gap-4 min-w-0">
                  <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-white/20 backdrop-blur">
                    <Link2 className="h-7 w-7" strokeWidth={2} />
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs font-semibold uppercase tracking-wider text-white/80">
                      Главная ссылка для записи
                    </p>
                    <h2 className="text-xl sm:text-2xl font-bold mt-1">Делитесь с клиентами</h2>
                    <p className="text-sm text-white/85 mt-2 max-w-xl">
                      Instagram, ВК, визитка, QR — одна ссылка. Telegram: вход на сайте, MAX: через бота.
                    </p>
                  </div>
                </div>
              </div>
              <div className="relative mt-5 flex flex-col sm:flex-row gap-3 sm:items-center">
                <div className="flex-1 min-w-0 rounded-xl bg-black/20 border border-white/20 px-4 py-3 font-mono text-sm break-all">
                  {clientBookingUrl}
                </div>
                <div className="flex flex-wrap gap-2 shrink-0">
                  <Button
                    size="lg"
                    className="!bg-white !text-primary hover:!bg-white/90 shadow-md"
                    onClick={() => copyLink(clientBookingUrl)}
                  >
                    <Copy className="h-4 w-4 mr-2" />
                    Копировать
                  </Button>
                  <a href={clientBookingUrl} target="_blank" rel="noreferrer">
                    <Button size="lg" variant="secondary" className="!bg-white/15 !text-white !border-white/30 hover:!bg-white/25">
                      <ExternalLink className="h-4 w-4 mr-2" />
                      Открыть
                    </Button>
                  </a>
                </div>
              </div>
            </div>
          )}

          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
            <StatCard label="Записи сегодня" value={stats.today} trend={stats.today > 0 ? '+активно' : undefined} hint="Подтверждённые" />
            <StatCard label="Клиенты" value={stats.clients} />
            <StatCard label="Выручка" value={formatPrice(stats.revenue)} accent="text-primary" />
            <StatCard label="Услуги" value={stats.services} hint="В прайсе" />
          </div>

          <div className="grid gap-6 lg:grid-cols-3">
            <Card className="lg:col-span-2">
              <CardHeader title="Записи на сегодня" action={<Button size="sm" variant="soft" onClick={() => setActiveSection('appointments')}>Все →</Button>} />
              {appointments.filter((a) => {
                const d = new Date(a.appointment_time);
                return d.toDateString() === new Date().toDateString() && a.status === 'confirmed';
              }).length === 0 ? (
                <p className="text-sm text-ink-muted py-6 text-center">На сегодня записей нет</p>
              ) : (
                <ul className="space-y-2">
                  {appointments
                    .filter((a) => {
                      const d = new Date(a.appointment_time);
                      return d.toDateString() === new Date().toDateString();
                    })
                    .slice(0, 6)
                    .map((apt) => (
                      <li key={apt.id} className="flex items-center justify-between gap-3 rounded-xl bg-slate-50 px-4 py-3">
                        <div className="flex items-center gap-3 min-w-0">
                          <span className="text-sm font-bold text-primary shrink-0">
                            {new Date(apt.appointment_time).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })}
                          </span>
                          <div className="min-w-0">
                            <p className="font-medium text-ink truncate">{apt.client_name || 'Клиент'}</p>
                            <p className="text-xs text-ink-muted truncate">{apt.service_name}</p>
                          </div>
                        </div>
                        <Badge tone={apt.status === 'confirmed' ? 'success' : apt.status === 'cancelled' ? 'danger' : 'warning'}>
                          {STATUS_LABELS[apt.status]?.label || apt.status}
                        </Badge>
                      </li>
                    ))}
                </ul>
              )}
            </Card>

            <Card>
              <CardHeader title="График записей" description="За неделю" />
              <MiniChart data={stats.weekChart} />
            </Card>
          </div>

          <div className="grid gap-6 lg:grid-cols-3">
            <Card>
              <CardHeader title="Быстрые действия" />
              <div className="grid grid-cols-2 gap-2">
                <Button variant="soft" size="sm" onClick={() => openPriceModal()}>+ Услуга</Button>
                <Button variant="soft" size="sm" onClick={() => setShowManualBook(true)}>+ Запись</Button>
                <Button variant="soft" size="sm" onClick={() => setShowBroadcast(true)}>Рассылка</Button>
                <Button variant="soft" size="sm" onClick={() => setActiveSection('links')}>Ссылки ботов</Button>
              </div>
            </Card>

            <Card className="lg:col-span-2">
              <CardHeader title="Последние клиенты" action={<Button size="sm" variant="ghost" onClick={() => setActiveSection('clients')}>Все</Button>} />
              {clients.length === 0 ? (
                <p className="text-sm text-ink-muted">Клиентов пока нет</p>
              ) : (
                <div className="grid sm:grid-cols-2 gap-2">
                  {clients.slice(0, 4).map((c) => (
                    <div key={c.id} className="flex items-center gap-3 rounded-xl bg-slate-50 p-3">
                      <div className="h-9 w-9 rounded-full bg-primary/20 flex items-center justify-center text-sm font-bold text-primary">
                        {(c.display_name || c.name || '?')[0]}
                      </div>
                      <div className="min-w-0">
                        <p className="font-medium text-sm truncate">{c.display_name || c.name || 'Клиент'}</p>
                        <p className="text-xs text-ink-muted truncate">{c.phone || '—'}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </Card>
          </div>
        </div>
      )}

      {activeSection === 'analytics' && (
        <AnalyticsSection api={api} toast={toast} />
      )}

      {activeSection === 'appointments' && (
        <Card>
          <CardHeader
            title="Записи"
            description="Управление визитами клиентов"
            action={<Button onClick={() => setShowManualBook(true)}>+ Новая запись</Button>}
          />
          {appointments.length === 0 ? (
            <EmptyState icon="◷" title="Записей пока нет" description="Клиенты появятся после бронирования по вашей ссылке или ручного добавления" actionLabel="Записать клиента" onAction={() => setShowManualBook(true)} />
          ) : (
            <div className="overflow-x-auto -mx-6 px-6">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-slate-100 text-left text-ink-muted">
                    <th className="pb-3 font-semibold">Клиент</th>
                    <th className="pb-3 font-semibold">Услуга</th>
                    <th className="pb-3 font-semibold">Время</th>
                    <th className="pb-3 font-semibold">Канал</th>
                    <th className="pb-3 font-semibold">Статус</th>
                    <th className="pb-3 font-semibold text-right">Действия</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {appointments.map((apt) => {
                    const st = STATUS_LABELS[apt.status] || STATUS_LABELS.confirmed;
                    return (
                      <tr key={apt.id} className="group">
                        <td className="py-4">
                          <p className="font-medium text-ink">{apt.client_name || '—'}</p>
                          <p className="text-xs text-ink-muted">{apt.client_phone || ''}</p>
                        </td>
                        <td className="py-4">
                          <p>{apt.service_name}</p>
                          <p className="text-xs text-ink-muted">
                            {formatPrice(apt.service_price)}
                            {apt.salon_master_name && ` · ${apt.salon_master_name}`}
                          </p>
                        </td>
                        <td className="py-4 whitespace-nowrap">{formatDateTime(apt.appointment_time)}</td>
                        <td className="py-4">
                          <Badge tone={apt.messenger === 'telegram' ? 'telegram' : 'max'} />
                        </td>
                        <td className="py-4">
                          <Badge tone={st.tone}>{st.label}</Badge>
                        </td>
                        <td className="py-4">
                          <div className="flex flex-wrap justify-end gap-1">
                            {apt.status === 'confirmed' && (
                              <>
                                <Button size="sm" variant="soft" onClick={() => handleAppointmentStatus(apt.id, 'completed')}>Завершить</Button>
                                <Button size="sm" variant="ghost" onClick={() => { setMessageTarget(apt); setShowMessageModal(true); }}>Написать</Button>
                                <Button size="sm" variant="ghost" onClick={() => handleAppointmentStatus(apt.id, 'cancelled')}>Отменить</Button>
                              </>
                            )}
                            <Button size="sm" variant="danger" onClick={() => handleDeleteAppointment(apt.id)}>Удалить</Button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </Card>
      )}

      {activeSection === 'chat' && (
        <ChatInboxSection api={api} toast={toast} onUpdated={refreshNavBadges} />
      )}

      {activeSection === 'reviews' && (
        <ReviewsSection api={api} toast={toast} onBadgesChange={refreshNavBadges} />
      )}

      {activeSection === 'invites' && (
        <RepeatInvitesSection api={api} toast={toast} />
      )}

      {activeSection === 'clients' && (
        <Card>
          <CardHeader title="Клиенты" description="Все, кто записывался к вам" action={<Button onClick={() => setShowBroadcast(true)}>Рассылка</Button>} />
          {clients.length === 0 ? (
            <EmptyState icon="◎" title="Клиентов пока нет" description="Они появятся после входа через MAX или Telegram" />
          ) : (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {clients.map((c) => (
                <div
                  key={c.id}
                  className="rounded-2xl border border-slate-100 bg-surface-subtle p-4 transition hover:border-primary-200 hover:shadow-soft"
                >
                  <button type="button" onClick={() => setSelectedClientId(c.id)} className="block w-full text-left">
                    <p className="font-semibold text-ink">{c.display_name || c.name || 'Без имени'}</p>
                    {c.phone && <p className="mt-1 text-sm text-ink-secondary">{c.phone}</p>}
                    <div className="mt-3 flex flex-wrap items-center gap-2">
                      <Badge tone={c.messenger === 'telegram' ? 'telegram' : 'max'} />
                      {Number(c.visit_count) > 0 ? (
                        <span className="text-xs text-ink-muted">{c.visit_count} визит(ов)</span>
                      ) : (
                        <span className="text-xs text-ink-muted">Авторизован</span>
                      )}
                    </div>
                    {(c.total_spent > 0 || c.last_visit) && (
                      <p className="mt-2 text-xs text-ink-secondary">
                        {Number(c.total_spent) > 0 && <span>{formatPrice(c.total_spent)}</span>}
                        {c.last_visit && (
                          <span>{Number(c.total_spent) > 0 ? ' · ' : ''}посл. {formatDate(c.last_visit)}</span>
                        )}
                      </p>
                    )}
                  </button>
                  <Button
                    type="button"
                    size="sm"
                    variant="danger"
                    className="mt-4"
                    onClick={() => setClientDeleteTarget(c)}
                  >
                    Удалить
                  </Button>
                </div>
              ))}
            </div>
          )}
        </Card>
      )}

      {activeSection === 'team' && (
        <SalonMastersSection masters={salonMasters} api={api} onChanged={loadData} toast={toast} />
      )}

      {activeSection === 'schedule' && (
        <div className="space-y-6">
          <TeamMasterSelect
            masters={salonMasters}
            value={selectedSalonMasterId}
            onChange={handleTeamMasterChange}
          />
          <Card>
            <CardHeader
              title="Рабочая неделя"
              description="Настройте часы для каждого дня"
              action={<Button onClick={handleScheduleSaveAll} loading={savingSchedule}>Сохранить расписание</Button>}
            />
            <div className="space-y-3">
              {scheduleDraft.map((day) => (
                <div key={day.day_of_week} className="flex flex-col gap-3 rounded-2xl border border-slate-100 p-4 sm:flex-row sm:items-center sm:justify-between">
                  <div className="flex items-center gap-3 min-w-[140px]">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={!day.is_day_off}
                        onChange={(e) => updateScheduleDay(day.day_of_week, { is_day_off: !e.target.checked })}
                        className="rounded border-slate-300 text-primary-600 focus:ring-primary-500"
                      />
                      <span className="font-medium text-sm">{DAYS[day.day_of_week]}</span>
                    </label>
                  </div>
                  {!day.is_day_off ? (
                    <div className="flex flex-wrap items-center gap-2">
                      <input type="time" value={day.start_time?.slice(0, 5) || '09:00'} onChange={(e) => updateScheduleDay(day.day_of_week, { start_time: e.target.value })} className="input-field w-auto" />
                      <span className="text-ink-muted">—</span>
                      <input type="time" value={day.end_time?.slice(0, 5) || '18:00'} onChange={(e) => updateScheduleDay(day.day_of_week, { end_time: e.target.value })} className="input-field w-auto" />
                    </div>
                  ) : (
                    <Badge tone="neutral">Выходной</Badge>
                  )}
                </div>
              ))}
            </div>
          </Card>

          <Card>
            <CardHeader title="Исключения" description="Отпуск, праздники, особые дни" action={<Button size="sm" onClick={() => setShowExceptionModal(true)}>+ Добавить</Button>} />
            {exceptions.length === 0 ? (
              <p className="text-sm text-ink-muted py-4">Исключений нет</p>
            ) : (
              <ul className="divide-y divide-slate-100">
                {exceptions.map((ex) => (
                  <li key={ex.id} className="flex items-center justify-between py-3">
                    <div>
                      <p className="font-medium">{new Date(ex.exception_date).toLocaleDateString('ru-RU')}</p>
                      <p className="text-sm text-ink-secondary">
                        {ex.is_working ? `Рабочий: ${ex.start_time}–${ex.end_time}` : 'Выходной'}
                      </p>
                    </div>
                    <Button size="sm" variant="danger" onClick={() => handleExceptionDelete(ex.id)}>Удалить</Button>
                  </li>
                ))}
              </ul>
            )}
          </Card>
        </div>
      )}

      {activeSection === 'prices' && (
        <Card>
          <TeamMasterSelect
            masters={salonMasters}
            value={selectedSalonMasterId}
            onChange={handleTeamMasterChange}
          />
          <CardHeader title="Услуги и прайс" description="Прайс привязан к выбранному мастеру" action={<Button onClick={() => openPriceModal()}>+ Услуга</Button>} />
          {priceList.length === 0 ? (
            <EmptyState icon="◇" title="Прайс пуст" description="Добавьте услуги с ценой и длительностью" actionLabel="Добавить услугу" onAction={() => openPriceModal()} />
          ) : (
            <div className="space-y-3">
              {priceList.map((item) => (
                <div key={item.id} className="flex gap-4 items-center rounded-2xl border border-slate-100 p-4 hover:border-primary-100 transition">
                  {item.image_url && (
                    <img src={mediaUrl(item.image_url)} alt="" className="h-16 w-16 rounded-xl object-cover" />
                  )}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="font-semibold text-ink">{item.name}</p>
                      {item.is_active === false && <Badge tone="neutral">Скрыта</Badge>}
                    </div>
                    <p className="text-sm text-ink-secondary">{item.duration_minutes} мин</p>
                  </div>
                  <p className="font-display text-lg font-bold text-primary-700">{formatPrice(item.price)}</p>
                  <div className="flex gap-1">
                    <Button size="sm" variant="secondary" onClick={() => openPriceModal(item)}>Изменить</Button>
                    <Button size="sm" variant="danger" onClick={() => handlePriceDelete(item.id)}>Удалить</Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>
      )}

      {activeSection === 'portfolio' && (
        <div className="space-y-6">
          <TeamMasterSelect
            masters={salonMasters}
            value={selectedSalonMasterId}
            onChange={handleTeamMasterChange}
          />
          <Card>
            <CardHeader title="Медиа для главной страницы" description="Фото, короткие видео или ссылки на рилсы. Видео — до 10 штук." />
            <form onSubmit={handlePortfolioUpload} className="grid gap-4 lg:grid-cols-5 lg:items-end">
              <Input label="Подпись" value={portfolioTitle} onChange={(e) => setPortfolioTitle(e.target.value)} placeholder="Работа, кабинет, процесс..." className="lg:col-span-2" />
              <div>
                <label className="label-field">Тип</label>
                <select className="input-field" value={portfolioMediaType} onChange={(e) => { setPortfolioMediaType(e.target.value); setPortfolioFile(null); setPortfolioVideoUrl(''); }}>
                  <option value="image">Фото</option>
                  <option value="video">Видео-файл</option>
                  <option value="external_video">Ссылка на видео</option>
                </select>
              </div>
              {portfolioMediaType === 'external_video' ? (
                <Input label="Ссылка" value={portfolioVideoUrl} onChange={(e) => setPortfolioVideoUrl(e.target.value)} placeholder="https://..." />
              ) : (
                <div className="w-full">
                  <label className="label-field">{portfolioMediaType === 'video' ? 'Видео' : 'Фото'}</label>
                  <input type="file" accept={portfolioMediaType === 'video' ? 'video/*' : 'image/*'} onChange={(e) => setPortfolioFile(e.target.files?.[0])} className="block w-full text-sm text-ink-secondary file:mr-4 file:rounded-lg file:border-0 file:bg-primary-50 file:px-4 file:py-2 file:font-semibold file:text-primary-700" />
                </div>
              )}
              <Button type="submit" loading={uploadingPortfolio}>Добавить</Button>
            </form>
          </Card>
          <Card>
            {portfolio.length === 0 ? (
              <EmptyState icon="▤" title="Медиа пока нет" description="Добавьте фото или видео для главной клиентской страницы" />
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {portfolio.map((item) => (
                  <div key={item.id} className="group relative aspect-square overflow-hidden rounded-2xl bg-slate-100">
                    {item.media_type === 'video' ? (
                      <video src={mediaUrl(item.video_url)} className="h-full w-full object-cover" muted />
                    ) : item.media_type === 'external_video' ? (
                      <div className="flex h-full w-full flex-col items-center justify-center bg-slate-900 p-4 text-center text-white">
                        <span className="text-3xl">▶</span>
                        <span className="mt-2 text-xs break-all">{item.video_url}</span>
                      </div>
                    ) : (
                      <img src={mediaUrl(item.image_url)} alt={item.title} className="h-full w-full object-cover" />
                    )}
                    <span className="absolute left-2 top-2 rounded-lg bg-white/90 px-2 py-1 text-[10px] font-bold uppercase text-ink">
                      {item.media_type === 'image' ? 'Фото' : 'Видео'}
                    </span>
                    {item.title && (
                      <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/70 to-transparent p-3">
                        <p className="text-white text-sm font-medium">{item.title}</p>
                      </div>
                    )}
                    <button type="button" onClick={() => handlePortfolioDelete(item.id)} className="absolute top-2 right-2 rounded-lg bg-white/90 px-2 py-1 text-xs font-semibold text-rose-600 opacity-0 group-hover:opacity-100 transition shadow">Удалить</button>
                  </div>
                ))}
              </div>
            )}
          </Card>
        </div>
      )}

      {activeSection === 'links' && links && (
        <div className="space-y-6">
          <div>
            <h1 className="font-display text-2xl font-bold">Ссылка для клиентов</h1>
            <p className="mt-1 text-sm text-ink-secondary">
              Одна ссылка для соцсетей. Клиент выбирает Telegram (вход на сайте) или MAX (через бота с возвратом)
            </p>
          </div>

          <Card className="border-primary/20 bg-gradient-to-br from-primary/5 to-white">
            <CardHeader title="Главная ссылка" description="Добавьте в Instagram*, ВК, визитку, QR-код" />
            <p className="text-sm break-all text-ink rounded-xl bg-slate-50 border border-slate-100 p-4">
              {links.client?.web || links.max?.web}
            </p>
            <div className="flex flex-wrap gap-2 mt-4">
              <Button onClick={() => copyLink(links.client?.web || links.max?.web)}>Копировать</Button>
              <a href={links.client?.web || links.max?.web} target="_blank" rel="noreferrer">
                <Button variant="secondary">Открыть страницу</Button>
              </a>
            </div>
          </Card>

          <Card>
            <div className="flex items-center gap-3 mb-3">
              <Badge tone="telegram" />
              <p className="text-sm text-ink-secondary">Клиент нажимает «Войти через Telegram» на странице записи</p>
            </div>
            <p className="text-xs text-ink-muted">
              Отдельная ссылка на бота нужна только для «Мои записи» в Telegram. Для записи к мастеру достаточно главной ссылки.
            </p>
            {links.telegram?.botDeepLink && (
              <div className="mt-4 rounded-xl bg-slate-50 border border-slate-100 p-4">
                <p className="text-xs font-semibold text-ink-muted mb-1">Бот (опционально)</p>
                <p className="text-sm break-all text-ink">{links.telegram.botDeepLink}</p>
                <Button className="mt-3" size="sm" variant="ghost" onClick={() => copyLink(links.telegram?.botDeepLink)}>
                  Копировать бота
                </Button>
              </div>
            )}
          </Card>

          <Card>
            <div className="flex items-center gap-3 mb-3">
              <Badge tone="max" />
              <p className="text-sm text-ink-secondary">Клиент нажимает «Продолжить в MAX» → бот → «Записаться» → возврат на сайт</p>
            </div>
            {links.max?.botDeepLink && (
              <div className="rounded-xl bg-slate-50 border border-slate-100 p-4">
                <p className="text-xs font-semibold text-ink-muted mb-1">Ссылка на MAX-бота (с привязкой к вам)</p>
                <p className="text-sm break-all text-ink">{links.max.botDeepLink}</p>
                <Button className="mt-3" size="sm" variant="secondary" onClick={() => copyLink(links.max?.botDeepLink)}>
                  Копировать ссылку бота
                </Button>
              </div>
            )}
          </Card>
        </div>
      )}

      {activeSection === 'profile' && (
        <div className="space-y-6">
        <NotifySettingsCard api={api} toast={toast} />
        <Card>
          <CardHeader title="Профиль мастера" description="Отображается на публичной странице записи" />
          <div className="flex flex-col sm:flex-row gap-6 mb-8">
            <div className="h-24 w-24 rounded-2xl bg-primary-50 overflow-hidden flex items-center justify-center shrink-0 border border-slate-100">
              {profile?.logo_url ? (
                <img src={mediaUrl(profile.logo_url)} alt="" className="h-full w-full object-cover" />
              ) : (
                <span className="text-3xl font-display font-bold text-primary-300">{profile?.name?.[0] || '?'}</span>
              )}
            </div>
            <div>
              <label className="label-field">Логотип</label>
              <input type="file" accept="image/*" onChange={handleLogoUpload} className="text-sm file:rounded-lg file:border-0 file:bg-primary-50 file:px-4 file:py-2 file:font-semibold file:text-primary-700" />
            </div>
          </div>
          <div className="grid gap-4 max-w-xl">
            <Input label="Имя" value={profileForm.name || ''} onChange={(e) => setProfileForm({ ...profileForm, name: e.target.value })} />
            <Input label="Салон" value={profileForm.salon_name || ''} onChange={(e) => setProfileForm({ ...profileForm, salon_name: e.target.value })} />
            <Textarea label="Описание" value={profileForm.description || ''} onChange={(e) => setProfileForm({ ...profileForm, description: e.target.value })} rows={4} />
            <Input label="Телефон" value={profileForm.phone || ''} onChange={(e) => setProfileForm({ ...profileForm, phone: e.target.value })} />
            <Input label="Адрес" value={profileForm.address || ''} onChange={(e) => setProfileForm({ ...profileForm, address: e.target.value })} />
            <Input label="Ссылка Яндекс.Карт" value={profileForm.yandex_maps_link || ''} onChange={(e) => setProfileForm({ ...profileForm, yandex_maps_link: e.target.value })} hint="https://yandex.ru/maps/..." />
            <Button onClick={handleProfileUpdate} loading={savingProfile} className="w-fit">Сохранить профиль</Button>
          </div>
        </Card>
        </div>
      )}

      <Modal open={showPriceModal} onClose={() => setShowPriceModal(false)} title={priceForm.id ? 'Редактировать услугу' : 'Новая услуга'} footer={
        <>
          <Button variant="secondary" onClick={() => setShowPriceModal(false)}>Отмена</Button>
          <Button type="submit" form="price-form">Сохранить</Button>
        </>
      }>
        <form id="price-form" onSubmit={handlePriceSubmit} className="space-y-4">
          <Input label="Название" required value={priceForm.name} onChange={(e) => setPriceForm({ ...priceForm, name: e.target.value })} />
          <div className="grid grid-cols-2 gap-4">
            <Input label="Цена, ₽" type="number" required value={priceForm.price} onChange={(e) => setPriceForm({ ...priceForm, price: e.target.value })} />
            <Input label="Минут" type="number" required value={priceForm.duration_minutes} onChange={(e) => setPriceForm({ ...priceForm, duration_minutes: e.target.value })} />
          </div>
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={priceForm.is_active} onChange={(e) => setPriceForm({ ...priceForm, is_active: e.target.checked })} className="rounded text-primary-600" />
            Показывать клиентам
          </label>
          <div>
            <label className="label-field">Фото услуги</label>
            <input type="file" accept="image/*" onChange={(e) => setPriceImage(e.target.files?.[0])} className="text-sm w-full" />
          </div>
        </form>
      </Modal>

      <Modal open={showExceptionModal} onClose={() => setShowExceptionModal(false)} title="Исключение в расписании" footer={
        <>
          <Button variant="secondary" onClick={() => setShowExceptionModal(false)}>Отмена</Button>
          <Button type="submit" form="exception-form">Сохранить</Button>
        </>
      }>
        <form id="exception-form" onSubmit={handleExceptionSubmit} className="space-y-4">
          <Input label="Дата" type="date" required value={exceptionForm.exception_date} onChange={(e) => setExceptionForm({ ...exceptionForm, exception_date: e.target.value })} />
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={exceptionForm.is_working} onChange={(e) => setExceptionForm({ ...exceptionForm, is_working: e.target.checked })} />
            Особый рабочий день (иначе — выходной)
          </label>
          {exceptionForm.is_working && (
            <div className="grid grid-cols-2 gap-4">
              <Input label="С" type="time" value={exceptionForm.start_time} onChange={(e) => setExceptionForm({ ...exceptionForm, start_time: e.target.value })} />
              <Input label="До" type="time" value={exceptionForm.end_time} onChange={(e) => setExceptionForm({ ...exceptionForm, end_time: e.target.value })} />
            </div>
          )}
        </form>
      </Modal>

      <Modal open={showManualBook} onClose={() => setShowManualBook(false)} title="Запись клиента" size="lg" footer={
        <>
          <Button variant="secondary" onClick={() => setShowManualBook(false)}>Отмена</Button>
          <Button type="submit" form="manual-book-form">Создать</Button>
        </>
      }>
        <form id="manual-book-form" onSubmit={handleManualBook} className="space-y-4">
          <div className="grid sm:grid-cols-2 gap-4">
            <Input label="Имя" value={manualBookForm.clientName} onChange={(e) => setManualBookForm({ ...manualBookForm, clientName: e.target.value })} />
            <Input label="Телефон" value={manualBookForm.clientPhone} onChange={(e) => setManualBookForm({ ...manualBookForm, clientPhone: e.target.value })} />
          </div>
          <Input label="Услуга" required value={manualBookForm.serviceName} onChange={(e) => setManualBookForm({ ...manualBookForm, serviceName: e.target.value })} list="services-list" />
          <datalist id="services-list">
            {priceList.map((p) => <option key={p.id} value={p.name} />)}
          </datalist>
          <div className="grid sm:grid-cols-3 gap-4">
            <Input label="Цена" type="number" value={manualBookForm.servicePrice} onChange={(e) => setManualBookForm({ ...manualBookForm, servicePrice: e.target.value })} />
            <Input label="Длительность, мин" type="number" value={manualBookForm.duration} onChange={(e) => setManualBookForm({ ...manualBookForm, duration: e.target.value })} />
            <Input label="Дата и время" type="datetime-local" required value={manualBookForm.appointmentTime} onChange={(e) => setManualBookForm({ ...manualBookForm, appointmentTime: e.target.value })} />
          </div>
        </form>
      </Modal>

      <Modal open={showBroadcast} onClose={() => setShowBroadcast(false)} title="Рассылка" description="Сообщение уйдёт клиентам в MAX или Telegram" footer={
        <>
          <Button variant="secondary" onClick={() => setShowBroadcast(false)}>Отмена</Button>
          <Button onClick={handleBroadcast}>Отправить</Button>
        </>
      }>
        <Textarea value={broadcastMessage} onChange={(e) => setBroadcastMessage(e.target.value)} placeholder="Текст сообщения..." rows={5} />
      </Modal>

      <ClientDetailModal
        clientId={selectedClientId}
        api={api}
        onClose={() => setSelectedClientId(null)}
        toast={toast}
        onSaved={async () => {
          try {
            const res = await api.get('/master/me/clients');
            setClients(res.data);
          } catch { /* ignore */ }
        }}
        onMessage={(client) => {
          setSelectedClientId(null);
          openClientMessage(client);
        }}
        onRepeatInvite={async (client) => {
          try {
            await api.post(`/master/me/clients/${client.id}/repeat-invite`);
            toast('Приглашение отправлено');
          } catch (err) {
            toast(err.response?.data?.error || 'Ошибка отправки', 'error');
          }
        }}
      />

      <Modal
        open={!!clientDeleteTarget}
        onClose={() => !deletingClient && setClientDeleteTarget(null)}
        title="Удалить клиента из базы?"
        description={clientDeleteTarget?.display_name || clientDeleteTarget?.name || 'Клиент'}
        footer={
          <>
            <Button variant="secondary" onClick={() => setClientDeleteTarget(null)} disabled={deletingClient}>
              Отмена
            </Button>
            <Button variant="danger" onClick={handleDeleteClient} loading={deletingClient}>
              Удалить
            </Button>
          </>
        }
      >
        <p className="text-sm text-ink-secondary">
          Клиент исчезнет из раздела «Клиенты». История записей и сообщения не удаляются.
        </p>
      </Modal>

      <Modal open={showMessageModal} onClose={() => { setShowMessageModal(false); setMessageTargetClient(null); }} title="Сообщение клиенту" footer={
        <>
          <Button variant="secondary" onClick={() => setShowMessageModal(false)}>Отмена</Button>
          <Button onClick={sendClientMessage}>Отправить</Button>
        </>
      }>
        <Textarea value={clientMessage} onChange={(e) => setClientMessage(e.target.value)} placeholder="Напоминание или уточнение..." rows={4} />
      </Modal>
    </DashboardLayout>
  );
}
