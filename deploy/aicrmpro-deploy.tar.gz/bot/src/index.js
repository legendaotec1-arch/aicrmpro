const express = require('express');
const cors = require('cors');
const axios = require('axios');

const app = express();
app.use(cors());
app.use(express.json());

const MAX_API_URL = process.env.MAX_API_URL || 'https://platform-api.max.ru';
const BOT_TOKEN = process.env.MAX_BOT_TOKEN || process.env.BOT_TOKEN;
const BACKEND_URL = process.env.BACKEND_URL || 'http://localhost:3000';
const PUBLIC_URL = (process.env.PUBLIC_URL || process.env.FRONTEND_URL || 'http://localhost:5173').replace(/\/$/, '');

const api = axios.create({
  baseURL: MAX_API_URL,
  headers: {
    Authorization: BOT_TOKEN
  }
});

async function sendMaxMessage(chatId, text, keyboard = null) {
  try {
    const payload = { chat_id: chatId, text };
    if (keyboard) payload.reply_markup = keyboard;
    await api.post('/messages/send', payload);
    return true;
  } catch (error) {
    console.error('Error sending message:', error.response?.data || error.message);
    return false;
  }
}

function buildBookingUrl(masterIdEncoded, userId) {
  const params = new URLSearchParams({ ch: 'max' });
  if (userId) params.set('uid', userId);
  return `${PUBLIC_URL}/m/${masterIdEncoded}?${params.toString()}`;
}

app.post('/webhook', async (req, res) => {
  try {
    const { update_type, chat_id, user, message, callback_query } = req.body;

    if (update_type === 'bot_started') {
      const chatId = chat_id;
      const userName = user?.name || 'друг';
      const welcomeText = `👋 Привет, ${userName}!\n\nMasterClient45 — запись к мастеру в MAX.\nВыберите действие:`;
      const keyboard = {
        inline: true,
        buttons: [
          [{ text: '📋 Записаться', url: `${PUBLIC_URL}?ch=max` }],
          [{ text: '💅 Услуги и цены', callback_data: 'services' }],
          [{ text: '📅 Мои записи', callback_data: 'my_bookings' }],
          [{ text: '⭐ Отзывы', callback_data: 'reviews' }]
        ]
      };
      await sendMaxMessage(chatId, welcomeText, keyboard);
      res.json({ ok: true });
      return;
    }

    if (callback_query) await handleCallbackQuery(callback_query);
    if (message) await handleMessage(message);

    res.json({ ok: true });
  } catch (error) {
    console.error('Webhook error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

async function handleMessage(message) {
  const chatId = message.chat?.id || message.fromChatId || message.chatId;
  const userId = message.from?.id?.toString() || message.userId?.toString() || chatId?.toString();
  const text = message.text;

  if (!chatId) return;

  if (text && text.startsWith('/start')) {
    const args = text.split(' ');

    if (args[1] && args[1].startsWith('ref_')) {
      const encoded = args[1].replace('ref_', '');
      const url = buildBookingUrl(encoded, userId);
      const welcomeText = '👋 Добро пожаловать!\n\nОткройте страницу записи к мастеру (MAX):';
      const keyboard = {
        inline: true,
        buttons: [[{ text: '📋 Записаться', url }]]
      };
      await sendMaxMessage(chatId, welcomeText, keyboard);
    } else {
      const keyboard = {
        inline: true,
        buttons: [
          [{ text: '📋 Записаться', url: `${PUBLIC_URL}?ch=max` }],
          [{ text: '📅 Мои записи', callback_data: 'my_bookings' }]
        ]
      };
      await sendMaxMessage(
        chatId,
        '👋 MasterClient45\n\nПерейдите по ссылке от мастера или откройте меню ниже.\n/help — справка',
        keyboard
      );
    }
    return;
  }

  if (text === '/help') {
    await sendMaxMessage(chatId, '📚 /start — начать\n/my — записи\n/cancel_<id> — отмена');
    return;
  }

  if (text === '/my') {
    try {
      const response = await axios.get(`${BACKEND_URL}/api/client/my/${userId}`, {
        params: { channel: 'max' }
      });
      const appointments = response.data;

      if (!appointments.length) {
        await sendMaxMessage(chatId, '📅 У вас пока нет записей');
        return;
      }

      let messageText = '📅 Ваши записи:\n\n';
      for (const apt of appointments) {
        const date = new Date(apt.appointment_time).toLocaleString('ru-RU', {
          day: 'numeric',
          month: 'long',
          hour: '2-digit',
          minute: '2-digit'
        });
        messageText += `💅 ${apt.service_name}\n📆 ${date}\n❌ /cancel_${apt.id}\n\n`;
      }
      await sendMaxMessage(chatId, messageText);
    } catch (error) {
      await sendMaxMessage(chatId, 'Ошибка при получении записей');
    }
    return;
  }

  if (text && text.startsWith('/cancel_')) {
    const appointmentId = text.split('_')[1];
    try {
      await axios.post(`${BACKEND_URL}/api/client/cancel/${appointmentId}`, {
        channel: 'max',
        userId
      });
      await sendMaxMessage(chatId, '✅ Запись отменена');
    } catch (error) {
      await sendMaxMessage(chatId, '❌ Не удалось отменить запись');
    }
    return;
  }

  await sendMaxMessage(chatId, 'Неизвестная команда. /help');
}

async function handleCallbackQuery(callbackQuery) {
  const { id, data, from } = callbackQuery;
  const chatId = from.id;
  const userId = from.id.toString();

  await api.post('/callbacks/answer', { callback_query_id: id });

  if (data === 'my_bookings') {
    await handleMessage({ chat: { id: chatId }, from: { id: chatId }, text: '/my' });
    return;
  }
  if (data === 'services') {
    await sendMaxMessage(chatId, '💅 Услуги и цены — откройте страницу записи по ссылке от мастера.');
    return;
  }
  if (data === 'reviews') {
    await sendMaxMessage(chatId, '⭐ Отзывы доступны на странице мастера в веб-приложении.');
    return;
  }

  if (data.startsWith('cancel_')) {
    const appointmentId = data.split('_')[1];
    try {
      await axios.post(`${BACKEND_URL}/api/client/cancel/${appointmentId}`, {
        channel: 'max',
        userId
      });
      await sendMaxMessage(chatId, '✅ Запись отменена');
    } catch (error) {
      await sendMaxMessage(chatId, '❌ Не удалось отменить');
    }
  }
}

app.post('/notify', async (req, res) => {
  try {
    const { maxUserId, message } = req.body;
    if (!maxUserId || !message) {
      return res.status(400).json({ error: 'Missing required fields' });
    }
    await sendMaxMessage(maxUserId, message);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: 'Failed to send notification' });
  }
});

app.get('/health', (req, res) => {
  res.json({ status: 'ok', channel: 'max', timestamp: new Date().toISOString() });
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`MAX Bot на порту ${PORT}`);
});

module.exports = app;
