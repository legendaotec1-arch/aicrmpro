const { v4: uuidv4 } = require('uuid');
const db = require('../config/database');

const VALID_CHANNELS = ['max', 'telegram'];

function normalizeChannel(channel) {
  const ch = (channel || 'max').toLowerCase();
  return VALID_CHANNELS.includes(ch) ? ch : 'max';
}

async function findOrCreateClient({ channel, maxUserId, telegramUserId, name, phone }) {
  const messenger = normalizeChannel(channel);

  if (messenger === 'max' && maxUserId) {
    const existing = await db.query('SELECT id FROM clients WHERE max_user_id = $1', [maxUserId]);
    if (existing.rows.length > 0) {
      return existing.rows[0].id;
    }
  }

  if (messenger === 'telegram' && telegramUserId) {
    const existing = await db.query('SELECT id FROM clients WHERE telegram_user_id = $1', [telegramUserId]);
    if (existing.rows.length > 0) {
      return existing.rows[0].id;
    }
  }

  if (phone) {
    const byPhone = await db.query(
      `SELECT id FROM clients
       WHERE phone = $1 AND messenger = $2
       ORDER BY created_at DESC LIMIT 1`,
      [phone, messenger]
    );
    if (byPhone.rows.length > 0) {
      const clientId = byPhone.rows[0].id;
      if (messenger === 'max' && maxUserId) {
        await db.query(
          'UPDATE clients SET max_user_id = COALESCE(max_user_id, $1), name = COALESCE(name, $2) WHERE id = $3',
          [maxUserId, name, clientId]
        );
      }
      if (messenger === 'telegram' && telegramUserId) {
        await db.query(
          'UPDATE clients SET telegram_user_id = COALESCE(telegram_user_id, $1), name = COALESCE(name, $2) WHERE id = $3',
          [telegramUserId, name, clientId]
        );
      }
      return clientId;
    }
  }

  const clientId = uuidv4();
  await db.query(
    `INSERT INTO clients (id, max_user_id, telegram_user_id, messenger, name, phone)
     VALUES ($1, $2, $3, $4, $5, $6)`,
    [
      clientId,
      messenger === 'max' ? maxUserId || null : null,
      messenger === 'telegram' ? telegramUserId || null : null,
      messenger,
      name || 'Клиент',
      phone || null
    ]
  );
  return clientId;
}

async function getClientByMessengerUserId(channel, userId) {
  if (!userId) return null;
  const messenger = normalizeChannel(channel);
  const column = messenger === 'telegram' ? 'telegram_user_id' : 'max_user_id';
  const result = await db.query(`SELECT id FROM clients WHERE ${column} = $1`, [userId]);
  return result.rows[0]?.id || null;
}

async function ensureSalonClientProfile(salonId, clientId) {
  if (!salonId || !clientId) return;
  await db.query(
    `INSERT INTO salon_client_profiles (salon_id, client_id, deleted_at, updated_at)
     VALUES ($1, $2, NULL, NOW())
     ON CONFLICT (salon_id, client_id)
     DO UPDATE SET deleted_at = NULL, updated_at = NOW()`,
    [salonId, clientId]
  );
}

module.exports = {
  normalizeChannel,
  findOrCreateClient,
  getClientByMessengerUserId,
  ensureSalonClientProfile,
  VALID_CHANNELS
};
