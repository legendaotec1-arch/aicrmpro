function encodeMasterId(masterId) {
  return Buffer.from(masterId).toString('base64');
}

function decodeMasterId(encoded) {
  return Buffer.from(encoded, 'base64').toString('utf8');
}

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

function resolveMasterId(param) {
  if (!param) return param;
  if (UUID_RE.test(param)) return param;
  try {
    const decoded = Buffer.from(param, 'base64').toString('utf8');
    if (UUID_RE.test(decoded)) return decoded;
  } catch (_) {
    /* ignore */
  }
  return param;
}

function getPublicUrl() {
  return (process.env.PUBLIC_URL || process.env.FRONTEND_URL || 'http://localhost:5173').replace(/\/$/, '');
}

function buildMasterLinks(masterId) {
  const encoded = encodeMasterId(masterId);
  const base = getPublicUrl();
  const clientUrl = `${base}/m/${encoded}`;
  const botPayload = `ref_${encoded}`;

  const telegramUsername = process.env.TELEGRAM_BOT_USERNAME;
  const maxBotUsername = process.env.MAX_BOT_USERNAME;

  const maxBotDeepLink = maxBotUsername
    ? `https://max.ru/${maxBotUsername}?start=${botPayload}`
    : null;
  const telegramBotDeepLink = telegramUsername
    ? `https://t.me/${telegramUsername}?start=${botPayload}`
    : null;

  const links = {
    client: { web: clientUrl },
    max: {
      web: clientUrl,
      botStart: botPayload,
      botDeepLink: maxBotDeepLink
    },
    telegram: {
      web: clientUrl,
      botStart: botPayload,
      botDeepLink: telegramBotDeepLink
    }
  };

  return { encodedMasterId: encoded, clientUrl, links };
}

module.exports = {
  encodeMasterId,
  decodeMasterId,
  resolveMasterId,
  getPublicUrl,
  buildMasterLinks
};
